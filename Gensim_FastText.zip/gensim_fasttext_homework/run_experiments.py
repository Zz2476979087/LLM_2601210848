"""Reproducible Gensim/news experiments; no labels are inferred from keywords.

Run with PYTHONHASHSEED=42 and OMP/BLAS thread counts set to 1.
Labels are the original page metadata; all January articles stay out of embedding
training. Hyperparameters are selected on validation data before opening tests.
"""
import os
for name in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS"):
    os.environ.setdefault(name, "1")

import csv
import gc
import hashlib
import importlib.metadata
import json
import logging
import platform
import random
import re
import time
import unicodedata
from collections import Counter, defaultdict
from pathlib import Path

import jieba
import numpy as np
import psutil
from gensim.models import FastText, Word2Vec
from gensim.models.callbacks import CallbackAny2Vec
from gensim.models.fasttext import ft_ngram_hashes
from gensim.models.word2vec import LineSentence
from sklearn.dummy import DummyClassifier
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix, f1_score
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import normalize

ROOT = Path(__file__).resolve().parent
RESULTS = ROOT / "results"
MODELS = ROOT / "models"
SEED = 42
TASKS = {"2": ["01", "06"], "3": ["01", "02", "06"],
         "5": ["01", "02", "03", "04", "06"],
         "12": [f"{i:02d}" for i in range(1, 13)]}
CONFIGS = [
    dict(name="w2v_sg100", kind="w2v", vector_size=100, sg=1),
    dict(name="ft_sg100", kind="ft", vector_size=100, sg=1),
    dict(name="ft_cbow100", kind="ft", vector_size=100, sg=0),
    dict(name="ft_sg50", kind="ft", vector_size=50, sg=1),
    dict(name="ft_sg200", kind="ft", vector_size=200, sg=1),
    dict(name="ft_window10", kind="ft", vector_size=100, sg=1, window=10),
    dict(name="ft_ngram36", kind="ft", vector_size=100, sg=1, min_n=3, max_n=6),
    dict(name="ft_bucket20k", kind="ft", vector_size=100, sg=1, bucket=20_000),
]


def dump(path, obj):
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2), encoding="utf-8")


def log(message):
    print(time.strftime("%H:%M:%S"), message, flush=True)


def canonical(text):
    return "".join(c for c in unicodedata.normalize("NFKC", text) if c.isalnum())


def word_shingles(tokens):
    return {hashlib.blake2b("\x1f".join(tokens[i:i + 5]).encode(), digest_size=8).digest()
            for i in range(len(tokens) - 4)}


def prepare():
    out = ROOT / "data" / "experiment"
    out.mkdir(exist_ok=True)
    if (out / "manifest.json").exists():
        return out, json.loads((out / "manifest.json").read_text(encoding="utf-8"))
    articles = []
    exact = set()
    signatures = {}
    index = defaultdict(set)
    excluded = Counter()
    raw_months = Counter()
    titles_january = set()
    # January precedes other months, so duplication against test candidates is
    # removed from embedding material, never the reverse.
    for line in (ROOT / "data/processed/articles.jsonl").open(encoding="utf-8"):
        a = json.loads(line)
        raw_months[a["date"][:6]] += 1
        if a["date"].startswith("199801"):
            titles_january.add(canonical(a["title"]))
        if len(a["tokens"]) < 30:
            excluded["fewer_than_30_tokens"] += 1
            continue
        # Only a minimal quality filter; no topic rules or invented labels.
        if len(a["paragraphs"]) == 1 and re.search(r"图片|照片|漫画|广告", a["title"]):
            excluded["single_paragraph_photo_or_ad"] += 1
            continue
        digest = hashlib.sha256(canonical(a["text"]).encode()).hexdigest()
        if digest in exact:
            excluded["exact_content_duplicate"] += 1
            continue
        shingles = word_shingles(a["tokens"])
        keys = sorted(shingles)[:8]
        candidates = set().union(*(index[key] for key in keys))
        duplicate = False
        for other in candidates:
            previous = signatures[other]
            if min(len(previous), len(shingles)) / max(len(previous), len(shingles)) < .85:
                continue
            if len(previous & shingles) / len(previous | shingles) >= .85:
                duplicate = True
                break
        if duplicate:
            excluded["near_duplicate_5gram_jaccard085"] += 1
            continue
        exact.add(digest)
        signatures[a["article_id"]] = shingles
        for key in keys:
            index[key].add(a["article_id"])
        articles.append(a)
    # Retain January separately, with metadata inaccessible to the classifier.
    january = [a for a in articles if a["date"].startswith("199801")]
    with (out / "january.jsonl").open("w", encoding="utf-8") as file:
        for a in january:
            file.write(json.dumps(a, ensure_ascii=False) + "\n")
    rng = random.Random(SEED)
    monthly = defaultdict(list)
    for a in articles:
        if not a["date"].startswith("199801"):
            # Retain paragraph boundaries; split sentence punctuation as in preprocessing.
            for p in a["paragraphs"]:
                for text in re.split(r"[。！？!?]+", p["text"]):
                    words = [w for w in text.split() if any(c.isalnum() for c in w)]
                    if len(words) >= 3:
                        monthly[a["date"][:6]].append(words)
    corpus = []
    month_counts = {}
    # 200k tokens per month keeps runtime manageable and balances the base corpus.
    for month in sorted(monthly):
        rng.shuffle(monthly[month])
        total = 0
        kept = 0
        for words in monthly[month]:
            if total >= 200_000:
                break
            corpus.append(words)
            total += len(words)
            kept += 1
        month_counts[month] = {"sentences": kept, "tokens": total}
    titles_path = ROOT / "data/external/thucnews_titles_train.txt"
    external = []
    seen_titles = set()
    removed_titles = Counter()
    for line in titles_path.open(encoding="utf-8"):
        title, _label = line.rstrip("\n").rsplit("\t", 1)
        key = canonical(title)
        if key in seen_titles:
            removed_titles["duplicate_title"] += 1
            continue
        if key in titles_january:
            removed_titles["matches_january_title"] += 1
            continue
        seen_titles.add(key)
        external.append(title)
    rng.shuffle(external)
    jieba.initialize()
    title_tokens = 0
    for title in external[:60_000]:
        words = [w.strip() for w in jieba.lcut(unicodedata.normalize("NFKC", title))
                 if any(c.isalnum() for c in w)]
        corpus.append(words)
        title_tokens += len(words)
    rng.shuffle(corpus)
    corpus_path = out / "embedding_corpus.txt"
    with corpus_path.open("w", encoding="utf-8") as file:
        for words in corpus:
            file.write(" ".join(words) + "\n")
    manifest = {
        "raw_articles_by_month": dict(raw_months),
        "retained_articles_by_month": dict(Counter(a["date"][:6] for a in articles)),
        "excluded_articles": dict(excluded), "january_articles": len(january),
        "january_page_counts": dict(sorted(Counter(a["page"] for a in january).items())),
        "base_months_sampled": month_counts,
        "external_source_titles": 180_000,
        "external_used_titles": min(60_000, len(external)),
        "external_used_tokens": title_tokens, "external_removed": dict(removed_titles),
        "embedding_sentences": len(corpus), "embedding_tokens": sum(map(len, corpus)),
        "embedding_corpus_sha256": hashlib.sha256(corpus_path.read_bytes()).hexdigest(),
        "january_not_used_in_embedding_training": True,
        "near_duplicate_method": "8 smallest word-5gram blake2b64 hashes shortlist; exact Jaccard>=.85 confirms; approximate candidate retrieval, not exhaustive.",
    }
    dump(out / "manifest.json", manifest)
    log(f"DATA {manifest}")
    return out, manifest


class Progress(CallbackAny2Vec):
    def __init__(self, name):
        self.name, self.epoch = name, 0

    def on_epoch_end(self, model):
        self.epoch += 1
        log(f"{self.name}: epoch {self.epoch}/{model.epochs}")


def train_models(folder):
    reports = []
    for config in CONFIGS:
        name = config["name"]
        model_path = MODELS / f"{name}.model"
        metadata_path = MODELS / f"{name}.json"
        if model_path.exists() and metadata_path.exists():
            reports.append(json.loads(metadata_path.read_text(encoding="utf-8")))
            continue
        params = dict(vector_size=config["vector_size"], sg=config["sg"],
                      window=config.get("window", 5), min_count=3,
                      negative=5, hs=0, sample=1e-3, epochs=5,
                      workers=4, seed=SEED, alpha=.025, min_alpha=.0001)
        if config["kind"] == "ft":
            params.update(min_n=config.get("min_n", 2), max_n=config.get("max_n", 4),
                          bucket=config.get("bucket", 100_000))
        cls = FastText if config["kind"] == "ft" else Word2Vec
        log(f"TRAIN {name} {params}")
        start = time.perf_counter()
        model = cls(**params)
        model.build_vocab(corpus_iterable=LineSentence(str(folder / "embedding_corpus.txt")))
        vocab_seconds = time.perf_counter() - start
        start_train = time.perf_counter()
        model.train(corpus_iterable=LineSentence(str(folder / "embedding_corpus.txt")),
                    total_examples=model.corpus_count, epochs=model.epochs,
                    callbacks=[Progress(name)])
        training_seconds = time.perf_counter() - start_train
        arrays = {k: int(v.nbytes) for k, v in vars(model.wv).items() if isinstance(v, np.ndarray)}
        arrays.update({f"model.{k}": int(v.nbytes) for k, v in vars(model).items()
                       if isinstance(v, np.ndarray)})
        metadata = dict(name=name, params=params, vocab=len(model.wv),
                        build_vocab_seconds=vocab_seconds, train_seconds=training_seconds,
                        total_seconds=time.perf_counter() - start,
                        array_bytes=sum(arrays.values()), arrays=arrays,
                        process_rss_after_training=psutil.Process().memory_info().rss)
        model.save(str(model_path))
        metadata["saved_bytes"] = sum(p.stat().st_size for p in MODELS.glob(f"{name}.model*"))
        dump(metadata_path, metadata)
        reports.append(metadata)
        del model
        gc.collect()
    dump(RESULTS / "training.json", reports)
    return reports


def load_model(name):
    cls = Word2Vec if name.startswith("w2v") else FastText
    return cls.load(str(MODELS / f"{name}.model"))


def split_indices(articles, seed):
    ids = np.arange(len(articles))
    labels = [a["page"] for a in articles]
    train, held = train_test_split(ids, test_size=.30, stratify=labels, random_state=seed)
    valid, test = train_test_split(held, test_size=.50,
                                  stratify=np.asarray(labels)[held], random_state=seed)
    return {"train": train, "valid": valid, "test": test}


def mean_features(model, articles, idf=None):
    wv = model.wv
    result = np.zeros((len(articles), wv.vector_size), dtype=np.float32)
    for i, a in enumerate(articles):
        counts = Counter(a["tokens"])
        weights_total = 0.
        for word, count in counts.items():
            # FastText membership permits inferred OOV vectors; Word2Vec doesn't.
            if word not in wv:
                continue
            if idf is None:
                weight = float(count)
            else:
                if word not in idf:
                    continue  # IDF vocabulary is fit on classification training only.
                weight = (1. + np.log(count)) * idf[word]
            result[i] += weight * wv[word]
            weights_total += weight
        if weights_total:
            result[i] /= weights_total
    return normalize(result, norm="l2", copy=False)


def select_classifier(X_train, y_train, X_valid, y_valid):
    candidates = []
    for c in (.1, 1., 10.):
        clf = LogisticRegression(C=c, class_weight="balanced", max_iter=2000,
                                 random_state=SEED, solver="lbfgs")
        start = time.perf_counter()
        clf.fit(X_train, y_train)
        score = f1_score(y_valid, clf.predict(X_valid), average="macro", zero_division=0)
        candidates.append((score, c, clf, time.perf_counter() - start))
    return max(candidates, key=lambda item: (item[0], -item[1])), [
        {"C": c, "valid_macro_f1": score, "fit_seconds": seconds}
        for score, c, _clf, seconds in candidates]


def scores(truth, prediction, labels):
    return {
        "accuracy": float(accuracy_score(truth, prediction)),
        "macro_f1": float(f1_score(truth, prediction, average="macro", zero_division=0)),
        "weighted_f1": float(f1_score(truth, prediction, average="weighted", zero_division=0)),
        "per_class": classification_report(truth, prediction, labels=labels,
                                             output_dict=True, zero_division=0),
        "confusion_matrix": confusion_matrix(truth, prediction, labels=labels).tolist(),
    }


def classification(folder):
    articles = [json.loads(line) for line in (folder / "january.jsonl").open(encoding="utf-8")]
    labels_all = np.array([a["page"] for a in articles])
    docs = [" ".join(a["tokens"]) for a in articles]
    mean_cache = {}
    for config in CONFIGS:
        name = config["name"]
        log(f"VECTORIZE {name}")
        model = load_model(name)
        mean_cache[name] = mean_features(model, articles)
        del model
        gc.collect()
    output = {"tasks": {}, "ablations": [], "split_seeds": [42, 43, 44], "selected_ft_by_seed": {}}
    baseline_ft = load_model("ft_sg100")
    for seed in output["split_seeds"]:
        splits = split_indices(articles, seed)
        dump(RESULTS / f"split_seed{seed}.json", {
            key: [articles[i]["article_id"] for i in idx] for key, idx in splits.items()})
        split_hashes = [{articles[i]["content_sha256"] for i in splits[key]}
                        for key in ("train", "valid", "test")]
        assert not (split_hashes[0] & split_hashes[1] or split_hashes[0] & split_hashes[2]
                    or split_hashes[1] & split_hashes[2])
        # Each repeat selects its own FT parameters on that repeat's validation
        # set; a previous split's validation data can overlap this split's test.
        seed_ablations = []
        for config in CONFIGS:
            if config["kind"] != "ft":
                continue
            X = mean_cache[config["name"]]
            (score, c, _clf, _seconds), trials = select_classifier(
                X[splits["train"]], labels_all[splits["train"]],
                X[splits["valid"]], labels_all[splits["valid"]])
            seed_ablations.append(dict(seed=seed, model=config["name"], valid_macro_f1=score,
                                      selected_C=c, C_trials=trials))
        output["ablations"].extend(seed_ablations)
        selected_ft = max(seed_ablations, key=lambda x: x["valid_macro_f1"])["model"]
        output["selected_ft_by_seed"][str(seed)] = selected_ft
        if seed == 42:
            output["selected_ft"] = selected_ft
        log(f"SELECTED FT ON VALIDATION seed={seed}: {selected_ft}")
        # Only now score held-out tests; no subsequent test-driven parameter changes.
        for task, labels in TASKS.items():
            ix = {key: np.array([i for i in idx if labels_all[i] in labels])
                  for key, idx in splits.items()}
            y = {key: labels_all[idx] for key, idx in ix.items()}
            tfidf = TfidfVectorizer(tokenizer=str.split, preprocessor=None, token_pattern=None,
                                    lowercase=False, min_df=2, max_features=50_000,
                                    sublinear_tf=True, norm="l2")
            start = time.perf_counter()
            tfidf.fit([docs[i] for i in ix["train"]])
            X_tfidf = tfidf.transform(docs)
            tfidf_seconds = time.perf_counter() - start
            idf = dict(zip(tfidf.get_feature_names_out(), tfidf.idf_))
            X_weighted = mean_features(baseline_ft, articles, idf)
            features = {
                "TF-IDF": X_tfidf,
                "Word2Vec-Mean": mean_cache["w2v_sg100"],
                "FastText-Mean": mean_cache["ft_sg100"],
                "FastText-TFIDF": X_weighted,
                "FastText-Selected": mean_cache[selected_ft],
            }
            result = {"seed": seed, "labels": labels,
                      "sizes": {key: len(idx) for key, idx in ix.items()},
                      "class_counts": {key: dict(Counter(y[key])) for key in y},
                      "tfidf_vocab": len(idf), "tfidf_fit_transform_seconds": tfidf_seconds,
                      "methods": {}}
            for method, X in features.items():
                log(f"CLASSIFY seed={seed} classes={task} {method}")
                (valid_f1, c, clf, fit_sec), trials = select_classifier(
                    X[ix["train"]], y["train"], X[ix["valid"]], y["valid"])
                pred = clf.predict(X[ix["test"]])
                item = scores(y["test"], pred, labels)
                item.update(selected_C=c, valid_macro_f1=valid_f1, C_trials=trials,
                            selected_fit_seconds=fit_sec)
                if seed == 42:
                    proba = clf.predict_proba(X[ix["test"]])
                    item["predictions"] = [
                        {"article_id": articles[i]["article_id"], "title": articles[i]["title"],
                         "truth": str(actual), "prediction": str(guess),
                         "confidence": float(max(p)), "tokens": len(articles[i]["tokens"])}
                        for i, actual, guess, p in zip(ix["test"], y["test"], pred, proba)]
                result["methods"][method] = item
                log(f"  test acc={item['accuracy']:.4f} macroF1={item['macro_f1']:.4f}")
            dummy = DummyClassifier(strategy="most_frequent")
            dummy.fit(np.zeros((len(y["train"]), 1)), y["train"])
            result["methods"]["Majority"] = scores(
                y["test"], dummy.predict(np.zeros((len(y["test"]), 1))), labels)
            output["tasks"].setdefault(task, []).append(result)
            dump(RESULTS / "classification.json", output)
    del baseline_ft
    return output, articles


def probes(articles):
    ft = load_model("ft_sg100")
    w2v = load_model("w2v_sg100")
    explicit = ft.wv.key_to_index
    assert set(explicit) == set(w2v.wv.key_to_index)
    counts = Counter(w for a in articles for w in a["tokens"])
    iv = sum(count for word, count in counts.items() if word in explicit)
    all_tokens = sum(counts.values())
    used = np.zeros(ft.wv.bucket, dtype=bool)
    for buckets in ft.wv.buckets_word:
        used[buckets] = True
    nearest = {}
    for word in ("经济", "改革", "发展", "足球", "科学", "教育", "北京", "金融"):
        nearest[word] = {"in_vocab": word in explicit}
        if word in explicit:
            nearest[word].update({"FastText": ft.wv.most_similar(word, topn=5),
                                   "Word2Vec": w2v.wv.most_similar(word, topn=5)})
    oov = []
    for word in ("人工智能产业化", "足球世界杯预选赛", "金融科技创新", "量子计算产业链"):
        buckets = ft_ngram_hashes(word, ft.wv.min_n, ft.wv.max_n, ft.wv.bucket)
        oov.append({"word": word, "in_vocab": word in explicit,
                    "ft_vector_available": word in ft.wv,
                    "w2v_vector_available": word in w2v.wv,
                    "ngram_count": len(buckets),
                    "trained_bucket_fraction": float(used[buckets].mean()) if buckets else 0,
                    "nearest": ft.wv.most_similar(word, topn=5)})
    # Numerical verification against the implementation, beyond qualitative neighbors.
    errors = []
    for word in ("经济", "足球", "北京"):
        if word not in explicit:
            continue
        idx = explicit[word]
        buckets = ft.wv.buckets_word[idx]
        reconstructed = (ft.wv.vectors_vocab[idx] + ft.wv.vectors_ngrams[buckets].sum(axis=0)) / (len(buckets) + 1)
        errors.append({"word": word, "max_abs_error": float(np.max(np.abs(reconstructed - ft.wv[word])))})
    restore = FastText.load(str(MODELS / "ft_sg100.model"))
    save_error = float(np.max(np.abs(restore.wv["经济"] - ft.wv["经济"])))
    result = {"nearest": nearest, "oov_examples": oov, "explicit_token_coverage": iv / all_tokens,
              "explicit_type_coverage": sum(w in explicit for w in counts) / len(counts),
              "january_token_count": all_tokens, "january_type_count": len(counts),
              "oov_token_count": all_tokens - iv,
              "oov_type_count": sum(w not in explicit for w in counts),
              "trained_bucket_fraction": float(used.mean()),
              "vector_composition_checks": errors, "save_load_max_abs_error": save_error}
    dump(RESULTS / "probes.json", result)
    assert max(item["max_abs_error"] for item in errors) < 1e-5
    assert save_error == 0
    return result


def main():
    RESULTS.mkdir(exist_ok=True)
    MODELS.mkdir(exist_ok=True)
    logging.basicConfig(level=logging.WARNING)
    env = {
        "python": platform.python_version(), "platform": platform.platform(),
        "logical_cpus": os.cpu_count(), "ram_bytes": psutil.virtual_memory().total,
        "packages": {name: importlib.metadata.version(name) for name in
                     ("gensim", "numpy", "scipy", "scikit-learn", "jieba", "matplotlib", "psutil")},
        "PYTHONHASHSEED": os.environ.get("PYTHONHASHSEED"),
        "embedding_workers": 4,
        "reproducibility_note": "Fixed seeds and persisted splits; multicore embedding scheduling is nondeterministic. Three split repeats reuse the same pretrained embeddings.",
    }
    dump(RESULTS / "environment.json", env)
    start = time.perf_counter()
    folder, manifest = prepare()
    train_models(folder)
    _classification, articles = classification(folder)
    probes(articles)
    dump(RESULTS / "runtime.json", {"wall_seconds": time.perf_counter() - start})
    log("ALL EXPERIMENTS COMPLETE")


if __name__ == "__main__":
    main()
