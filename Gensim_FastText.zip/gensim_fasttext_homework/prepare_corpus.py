"""Inspect and clean the supplied segmented People's Daily archive after extraction.

Uses only the Python standard library. Never modifies files under data/raw.
"""

import argparse
import csv
import hashlib
import json
import re
import unicodedata
from collections import Counter
from pathlib import Path


ROW = re.compile(r"^(\d{8})-(\d{2})-(\d{3})-(\d{3})\s+(.*)$")
PRONUNCIATION = re.compile(r"\{[^{}]*\}")


def decode_source(raw):
    for encoding in ("utf-8-sig", "gb18030"):
        try:
            return raw.decode(encoding), encoding, []
        except UnicodeDecodeError:
            pass
    # Record every invalid byte sequence rather than silently ignoring damage.
    errors = []
    offset = 0
    while offset < len(raw):
        try:
            raw[offset:].decode("gb18030")
            break
        except UnicodeDecodeError as error:
            start, end = offset + error.start, offset + error.end
            errors.append({"byte_offset": start, "bytes_hex": raw[start:end].hex()})
            offset = end
    return raw.decode("gb18030", errors="replace"), "gb18030-with-replacement", errors


def clean_line(text):
    text = PRONUNCIATION.sub("", text)
    text = unicodedata.normalize("NFKC", text).replace("\ufffd", " ")
    text = " ".join(text.split())
    tokens = [
        word for word in text.split()
        if any(unicodedata.category(char)[0] in "LN" for char in word)
    ]
    return text, tokens


def prepare(raw_dir, output_dir):
    paths = sorted(raw_dir.rglob("*.txt"))
    if not paths:
        raise ValueError(f"No .txt corpus files under {raw_dir}")
    output_dir.mkdir(parents=True, exist_ok=True)
    sentence_dir = output_dir / "sentences_by_month"
    sentence_dir.mkdir(exist_ok=True)
    articles = {}
    file_reports = []

    for path in paths:
        raw = path.read_bytes()
        decoded, encoding, decode_errors = decode_source(raw)
        report = {
            "file": path.name, "sha256": hashlib.sha256(raw).hexdigest(),
            "bytes": len(raw), "encoding": encoding,
            "decode_errors": decode_errors, "paragraphs": 0,
            "pronunciation_annotations": 0, "duplicate_records": [],
        }
        file_article_ids = set()
        for line_number, line in enumerate(decoded.splitlines(), 1):
            if not line.strip():
                continue
            match = ROW.fullmatch(line)
            if not match:
                raise ValueError(f"Unrecognized record at {path.name}:{line_number}")
            date, page, number, paragraph_number, original = match.groups()
            article_id = f"{date}-{page}-{number}"
            report["pronunciation_annotations"] += len(PRONUNCIATION.findall(original))
            text, tokens = clean_line(original)
            article = articles.setdefault(article_id, {
                "article_id": article_id, "date": date, "page": page,
                "source_file": path.name, "paragraphs": [], "_paragraph_ids": {},
            })
            report["paragraphs"] += 1
            file_article_ids.add(article_id)
            previous = article["_paragraph_ids"].get(paragraph_number, [])
            if previous:
                exact = text in previous
                report["duplicate_records"].append({
                    "record_id": f"{article_id}-{paragraph_number}",
                    "source_line": line_number,
                    "action": "skip_identical_copy" if exact else "keep_distinct_text_in_source_order",
                })
                if exact:
                    continue
            article["_paragraph_ids"].setdefault(paragraph_number, []).append(text)
            article["paragraphs"].append({
                "paragraph_id": paragraph_number, "source_line": line_number,
                "text": text, "tokens": tokens,
            })
        report["articles"] = len(file_article_ids)
        file_reports.append(report)

    months = Counter()
    duplicate_groups = {}
    for article in articles.values():
        del article["_paragraph_ids"]
        # Keep source order: one source record reuses an ID for distinct text.
        article["title"] = article["paragraphs"][0]["text"]
        article["text"] = "\n".join(p["text"] for p in article["paragraphs"])
        article["tokens"] = [word for p in article["paragraphs"] for word in p["tokens"]]
        # Removing spacing also detects duplicates with differing segmentation.
        article["content_sha256"] = hashlib.sha256(
            "".join(article["text"].split()).encode("utf-8")
        ).hexdigest()
        duplicate_groups.setdefault(article["content_sha256"], []).append(article["article_id"])
        months[article["date"][:6]] += 1

    ordered = [articles[key] for key in sorted(articles)]
    with (output_dir / "articles.jsonl").open("w", encoding="utf-8") as file:
        for article in ordered:
            file.write(json.dumps(article, ensure_ascii=False) + "\n")
    january = [a for a in ordered if a["date"].startswith("199801")]
    with (output_dir / "january_articles.jsonl").open("w", encoding="utf-8") as file:
        for article in january:
            file.write(json.dumps(article, ensure_ascii=False) + "\n")
    with (output_dir / "annotation_january.csv").open(
        "w", encoding="utf-8-sig", newline=""
    ) as file:
        writer = csv.DictWriter(file, fieldnames=["article_id", "date", "page", "title", "text", "label"])
        writer.writeheader()
        for article in january:
            writer.writerow({key: article.get(key, "") for key in writer.fieldnames})
    for month in sorted(months):
        with (sentence_dir / f"{month[:4]}-{month[4:]}.txt").open("w", encoding="utf-8") as file:
            for article in ordered:
                if article["date"].startswith(month):
                    for paragraph in article["paragraphs"]:
                        # Each original paragraph remains a separate context unit.
                        # Split at sentence-ending punctuation before dropping it.
                        for sentence in re.split(r"[。！？!?]+", paragraph["text"]):
                            _, tokens = clean_line(sentence)
                            if tokens:
                                file.write(" ".join(tokens) + "\n")
    duplicates = [ids for ids in duplicate_groups.values() if len(ids) > 1]
    stats = {
        "files": file_reports, "total_articles": len(ordered),
        "total_paragraphs": sum(item["paragraphs"] for item in file_reports),
        "retained_paragraphs": sum(len(a["paragraphs"]) for a in ordered),
        "articles_by_month": dict(sorted(months.items())),
        "january_articles_by_page": dict(sorted(Counter(a["page"] for a in january).items())),
        "total_tokens": sum(len(a["tokens"]) for a in ordered),
        "exact_duplicate_groups": duplicates,
        "explicit_topic_labels_found": False,
        "note": "Page numbers are metadata, not verified topic labels. Labels in the CSV are intentionally blank.",
    }
    (output_dir / "corpus_stats.json").write_text(
        json.dumps(stats, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(json.dumps({key: value for key, value in stats.items() if key not in {"files", "exact_duplicate_groups"}}, ensure_ascii=False, indent=2))
    print(f"Invalid byte sequences: {sum(len(f['decode_errors']) for f in file_reports)}")
    print(f"Exact duplicate groups: {len(duplicates)}")


if __name__ == "__main__":
    root = Path(__file__).resolve().parent
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--raw-dir", type=Path, default=root / "data" / "raw")
    parser.add_argument("--output-dir", type=Path, default=root / "data" / "processed")
    args = parser.parse_args()
    prepare(args.raw_dir, args.output_dir)
