"""Render report tables as images while retaining charts at their body positions.

The Markdown preserves $$...$$ formulas. A self-contained HTML preview embeds
tables, plots and rendered formulas, so opening it needs no Markdown renderer.
"""
import base64
import html
import io
import re
import unicodedata
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib import font_manager


TITLES = ["数据划分", "训练时间与主要参数数组内存", "不同表示方法的分类效果",
          "FastText 参数实验", "相似词查询", "未登录词查询",
          "部分版面的分类结果", "分类错误样例", "论文与实现对应关系"]


def width(text):
    return sum(2 if unicodedata.east_asian_width(char) in "WF" else 1 for char in text)


def wrap(text, limit):
    lines, line, size = [], "", 0
    for char in text:
        step = 2 if unicodedata.east_asian_width(char) in "WF" else 1
        if size + step > limit and line:
            lines.append(line)
            line, size = "", 0
        line += char
        size += step
    lines.append(line)
    return "\n".join(lines)


def render_table(rows, title, path):
    rows = [[re.sub(r"\*\*|`", "", cell) for cell in row] for row in rows]
    col_sizes = [min(54, max(10, max(width(row[col]) for row in rows) + 3))
                 for col in range(len(rows[0]))]
    wrapped = [[wrap(cell, col_sizes[col] - 2) for col, cell in enumerate(row)] for row in rows]
    row_sizes = [max(cell.count("\n") + 1 for cell in row) * .25 + .17 for row in wrapped]
    figure_width = max(7.5, sum(col_sizes) * .075)
    table_height = sum(row_sizes)
    fig = plt.figure(figsize=(figure_width, table_height + .65))
    ax = fig.add_axes([.02, .02, .96, table_height / (table_height + .65)])
    ax.axis("off")
    table = ax.table(cellText=wrapped, cellLoc="center", bbox=[0, 0, 1, 1],
                     colWidths=[value / sum(col_sizes) for value in col_sizes])
    table.auto_set_font_size(False)
    table.set_fontsize(11)
    for row in range(len(rows)):
        for col in range(len(rows[0])):
            cell = table[row, col]
            cell.set_height(row_sizes[row] / table_height)
            cell.set_edgecolor("#9AA8B3")
            cell.set_linewidth(.7)
            cell.PAD = .06
            if row == 0:
                cell.set_facecolor("#E5EDF3")
                cell.get_text().set_weight("bold")
            else:
                cell.set_facecolor("white" if row % 2 else "#F6F8FA")
    fig.text(.5, 1 - .24 / (table_height + .65), title, ha="center", va="center",
             fontsize=12, weight="bold")
    fig.savefig(path, dpi=200, bbox_inches="tight", pad_inches=.10, facecolor="white")
    fig.savefig(path.with_suffix(".svg"), bbox_inches="tight", pad_inches=.10, facecolor="white")
    plt.close(fig)


def image_data(path):
    return "data:image/png;base64," + base64.b64encode(path.read_bytes()).decode("ascii")


def inline(text):
    text = html.escape(text)
    text = re.sub(r"`([^`]+)`", r"<code>\1</code>", text)
    text = re.sub(r"\*\*(.+?)\*\*", r"<strong>\1</strong>", text)
    text = re.sub(r"\[([^]]+)\]\((https?://[^)]+)\)", r'<a href="\2">\1</a>', text)
    return text


def make_preview(text, folder):
    blocks = []
    formula = False
    math_lines = []
    formulas = 0
    for block in re.split(r"\n\s*\n", text):
        block = block.strip()
        if not block:
            continue
        if block.startswith("$$") and block.endswith("$$"):
            expression = block[2:-2].strip()
            fig = plt.figure(figsize=(12, 1))
            fig.text(.5, .5, "$" + expression + "$", ha="center", va="center", fontsize=16)
            buffer = io.BytesIO()
            fig.savefig(buffer, format="png", dpi=180, bbox_inches="tight", pad_inches=.15)
            plt.close(fig)
            src = "data:image/png;base64," + base64.b64encode(buffer.getvalue()).decode("ascii")
            blocks.append(f'<div class="formula"><img src="{src}" alt="{html.escape(expression)}"></div>')
            formulas += 1
            continue
        image_match = re.fullmatch(r"!\[([^]]*)\]\(([^)]+)\)", block)
        if image_match:
            alt, relative = image_match.groups()
            src = image_data(folder / relative)
            blocks.append(f'<figure><img src="{src}" alt="{html.escape(alt)}"></figure>')
        elif block.startswith("#"):
            match = re.match(r"^(#{1,6})\s+(.+)$", block)
            if match:
                level = len(match.group(1))
                blocks.append(f'<h{level}>{inline(match.group(2))}</h{level}>')
        elif re.match(r"^\d+\. ", block):
            items = [re.sub(r"^\d+\.\s*", "", line) for line in block.splitlines()]
            blocks.append("<ol>" + "".join(f"<li>{inline(item)}</li>" for item in items) + "</ol>")
        else:
            blocks.append("<p>" + inline(block).replace("\n", " ") + "</p>")
    style = """body{max-width:1100px;margin:35px auto;padding:0 24px;color:#20252b;
font:16px/1.85 'Microsoft YaHei','Noto Sans CJK SC',sans-serif;background:white}
h1{font-size:27px;line-height:1.5}h2{font-size:22px;margin-top:32px;border-bottom:1px solid #ddd;padding-bottom:6px}
h3{font-size:18px;margin-top:24px}p{margin:14px 0}figure{margin:22px 0}img{max-width:100%;height:auto}
.formula{text-align:center;margin:20px 0}.formula img{max-height:115px;width:auto}code{font-size:.92em;background:#f4f5f6;padding:2px 4px}
@media print{body{margin:0;max-width:none;font-size:11pt}figure,.formula{break-inside:avoid}h2,h3{break-after:avoid}}
"""
    return '<!doctype html><html lang="zh-CN"><meta charset="utf-8"><title>人民日报 FastText 实验报告</title><style>' + style + "</style><body>" + "\n".join(blocks) + "</body></html>"


def apply_layout(text, folder):
    folder = Path(folder)
    tables = folder / "tables"
    tables.mkdir(exist_ok=True)
    font_path = Path("C:/Windows/Fonts/msyh.ttc")
    if font_path.exists():
        font_manager.fontManager.addfont(str(font_path))
    plt.rcParams.update({"font.family": "Microsoft YaHei", "axes.unicode_minus": False})
    count = 0

    def replace(match):
        nonlocal count
        count += 1
        lines = [line.strip() for line in match.group(0).strip().splitlines()]
        rows = [[part.strip() for part in line.strip("|").split("|")] for line in lines]
        rows.pop(1)
        assert len({len(row) for row in rows}) == 1
        title = f"表 {count}  {TITLES[count-1]}"
        render_table(rows, title, tables / f"table_{count:02d}.png")
        return f"![{title}](tables/table_{count:02d}.png)\n"

    pattern = r"(?m)^\|.*\|[ \t]*\n\|(?:[ \t]*:?-+:?[ \t]*\|)+[ \t]*\n(?:\|.*\|[ \t]*(?:\n|$))+"
    text = re.sub(pattern, replace, text)
    assert count == 9, count
    text = re.sub(r"\$\$\s*([\s\S]*?)\s*\$\$", lambda m: "$$" + re.sub(r"\s+", " ", m.group(1)).strip() + "$$", text)
    # Chart image positions are retained exactly where the report places them.
    assert text.count("](figures/") == 3
    assert not re.search(r"(?m)^\|", text)
    preview = make_preview(text, folder)
    (folder / "Gensim_FastText_实验报告_预览.html").write_text(preview, encoding="utf-8")
    return text
