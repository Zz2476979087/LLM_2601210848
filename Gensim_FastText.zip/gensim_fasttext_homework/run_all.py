"""Run the complete experiment, or regenerate the report from saved results."""
import argparse
import os
from pathlib import Path
import subprocess
import sys


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--report-only", action="store_true", help="Only regenerate charts and the Markdown report")
    args = parser.parse_args()
    root = Path(__file__).resolve().parent
    env = os.environ.copy()
    env.update(PYTHONHASHSEED="42", PYTHONIOENCODING="utf-8",
               OMP_NUM_THREADS="1", OPENBLAS_NUM_THREADS="1", MKL_NUM_THREADS="1")
    if args.report_only:
        scripts = ["build_report.py", "build_piazza_report.py"]
    else:
        if not list((root / "data/raw").rglob("*.txt")):
            raise FileNotFoundError("Extract the People's Daily archive into data/raw before running.")
        scripts = ["fetch_external.py", "prepare_corpus.py", "run_experiments.py", "build_report.py", "build_piazza_report.py"]
    for script in scripts:
        print(f"Running {script}", flush=True)
        subprocess.run([sys.executable, str(root / script)], cwd=root, env=env, check=True)
    print(root / "results/piazza_rich_text.html")


if __name__ == "__main__":
    main()
