"""Download the public news-title source and verify the experiment's SHA-256."""
import hashlib
from pathlib import Path
from urllib.request import Request, urlopen

URL = "https://raw.githubusercontent.com/649453932/Chinese-Text-Classification-Pytorch/master/THUCNews/data/train.txt"
SHA256 = "ba6fcbbb8fb809a9eb2be443b6b4db533c147861d94ebe0931b8c6092d8abe94"
destination = Path(__file__).resolve().parent / "data/external/thucnews_titles_train.txt"
destination.parent.mkdir(parents=True, exist_ok=True)
if destination.exists() and hashlib.sha256(destination.read_bytes()).hexdigest() == SHA256:
    print("Existing external corpus matches the experiment checksum.")
else:
    with urlopen(Request(URL, headers={"User-Agent": "Mozilla/5.0"}), timeout=60) as response:
        raw = response.read()
    actual = hashlib.sha256(raw).hexdigest()
    if actual != SHA256:
        raise ValueError(f"Source changed: expected {SHA256}, got {actual}; do not silently reuse old results.")
    destination.write_bytes(raw)
    print(f"Downloaded and verified {len(raw):,} bytes.")
