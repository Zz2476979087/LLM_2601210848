"""Create the Markdown+LaTeX report and publication-style static charts."""
import csv
import json
import re
import shutil
import zipfile
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib import font_manager
import numpy as np

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "results"
FIG = OUT / "figures"
FIG.mkdir(exist_ok=True)
font_manager.fontManager.addfont(r"C:\Windows\Fonts\msyh.ttc")
plt.rcParams.update({
    "font.family": "Microsoft YaHei", "font.size": 10,
    "axes.spines.top": False, "axes.spines.right": False,
    "axes.unicode_minus": False, "figure.facecolor": "white",
    "axes.facecolor": "white", "savefig.facecolor": "white",
    "svg.fonttype": "none", "axes.titleweight": "bold",
})
COLORS = ["#176B87", "#D07836", "#4C956C", "#8963A5", "#D35563", "#929AA5"]
METHODS = ["TF-IDF", "Word2Vec-Mean", "FastText-Mean", "FastText-TFIDF", "FastText-Selected"]
NAMES = {"w2v_sg100": "Word2Vec SG100", "ft_sg100": "FastText SG100",
         "ft_cbow100": "FastText CBOW100", "ft_sg50": "FastText SG50",
         "ft_sg200": "FastText SG200", "ft_window10": "FastText window10",
         "ft_ngram36": "FastText ngram3–6", "ft_bucket20k": "FastText bucket20k"}


def read(path):
    return json.loads(path.read_text(encoding="utf-8"))


def table(headers, rows):
    def cell(value):
        return str(value).replace("|", "／").replace("\n", " ")
    return "\n".join([
        "| " + " | ".join(map(cell, headers)) + " |",
        "| " + " | ".join("---" for _ in headers) + " |",
        *("| " + " | ".join(map(cell, row)) + " |" for row in rows),
    ])


def save(fig, name):
    fig.savefig(FIG / f"{name}.png", dpi=200, bbox_inches="tight")
    fig.savefig(FIG / f"{name}.svg", bbox_inches="tight")
    plt.close(fig)


def percent(value):
    return f"{100 * value:.2f}"


def summary(results, task, method, metric):
    values = np.array([r["methods"][method][metric] for r in results["tasks"][task]])
    return float(values.mean()), float(values.std(ddof=1))


def export_csv(path, headers, rows):
    with path.open("w", encoding="utf-8-sig", newline="") as file:
        writer = csv.writer(file)
        writer.writerow(headers)
        writer.writerows(rows)


def plots(data, train, cls, probes):
    pages = list(data["january_page_counts"])
    counts = list(data["january_page_counts"].values())
    fig, ax = plt.subplots(figsize=(10, 4))
    bars = ax.bar(pages, counts, color=COLORS[0], width=.7)
    ax.bar_label(bars, padding=3, fontsize=9)
    ax.set(xlabel="原始版面号", ylabel="文章数", ylim=(0, max(counts) * 1.15),
           title=f"附图 A  一月分类数据分布（筛选后 {data['january_articles']:,} 篇）")
    ax.grid(axis="y", alpha=.15)
    ax.set_axisbelow(True)
    fig.tight_layout()
    save(fig, "01_class_distribution")

    tasks = ["2", "3", "5", "12"]
    fig, axes = plt.subplots(1, 2, figsize=(12.5, 4.4), sharex=True)
    for ax, metric, title in zip(axes, ["macro_f1", "accuracy"], ["Macro-F1", "Accuracy"]):
        for method, color in zip(METHODS, COLORS):
            values = [summary(cls, task, method, metric) for task in tasks]
            ax.errorbar(range(4), [v[0] * 100 for v in values],
                        yerr=[v[1] * 100 for v in values], marker="o", linewidth=1.8,
                        capsize=3, label=method, color=color)
        ax.set(xticks=range(4), xticklabels=tasks, xlabel="类别数", ylabel=f"{title}（%）",
               ylim=(25, 100), title=title)
        ax.grid(alpha=.15)
    axes[1].legend(fontsize=8, loc="lower left")
    fig.suptitle("图 1  不同文本表示方法的分类效果（均值 ± 标准差）", fontsize=12, fontweight="bold")
    fig.tight_layout()
    save(fig, "02_classification_comparison")

    fig, axes = plt.subplots(1, 2, figsize=(12, 4.4))
    labels = [NAMES[t["name"]].replace("FastText ", "FT ").replace("Word2Vec ", "W2V ") for t in train]
    for ax, values, title, xlabel in [
        (axes[0], [t["total_seconds"] for t in train], "计时：建词表＋5 轮训练", "秒"),
        (axes[1], [t["array_bytes"] / 2**20 for t in train], "主要常驻 NumPy 数组", "MiB"),
    ]:
        bars = ax.barh(labels, values, color=[COLORS[1]] + [COLORS[0]] * (len(train) - 1))
        ax.bar_label(bars, fmt="%.1f", padding=3, fontsize=8)
        ax.invert_yaxis()
        ax.set(title=title, xlabel=xlabel, xlim=(0, max(values) * 1.2))
        ax.grid(axis="x", alpha=.15)
        ax.set_axisbelow(True)
    fig.suptitle("附图 B  词向量训练时间与主要参数数组内存", fontsize=12, fontweight="bold")
    fig.tight_layout()
    save(fig, "03_training_cost")

    ab = [a for a in cls["ablations"] if a["seed"] == 42]
    fig, ax = plt.subplots(figsize=(9.8, 4.5))
    xs = [NAMES[a["model"]].replace("FastText ", "") for a in ab]
    vals = [a["valid_macro_f1"] * 100 for a in ab]
    bars = ax.bar(xs, vals, color=[COLORS[2] if a["model"] == cls["selected_ft"] else COLORS[0] for a in ab])
    ax.bar_label(bars, fmt="%.2f", padding=3, fontsize=9)
    ax.axhline(ab[0]["valid_macro_f1"] * 100, color=COLORS[1], linestyle="--", linewidth=1,
               label="SG100 基准")
    ax.set(ylabel="验证集 Macro-F1（%）", ylim=(0, max(vals) * 1.18),
           title="图 2  FastText 参数对比（12 类验证集，seed=42）")
    ax.tick_params(axis="x", labelrotation=15)
    ax.legend(fontsize=9)
    ax.grid(axis="y", alpha=.15)
    ax.set_axisbelow(True)
    fig.tight_layout()
    save(fig, "04_parameter_ablation")

    main = cls["tasks"]["12"][0]
    fig, axes = plt.subplots(1, 2, figsize=(13, 5.8))
    for ax, method in zip(axes, ["TF-IDF", "FastText-Selected"]):
        matrix = np.array(main["methods"][method]["confusion_matrix"])
        rate = matrix / np.maximum(matrix.sum(axis=1, keepdims=True), 1)
        image = ax.imshow(rate, cmap="Blues", vmin=0, vmax=1)
        for row in range(12):
            for col in range(12):
                if rate[row, col] >= .08 or row == col:
                    ax.text(col, row, f"{100 * rate[row,col]:.0f}", ha="center", va="center", fontsize=7,
                            color="white" if rate[row, col] > .5 else "#172F43")
        ax.set(xticks=range(12), xticklabels=main["labels"], yticks=range(12), yticklabels=main["labels"],
               xlabel="预测版面", ylabel="真实版面", title=method)
        ax.spines[:].set_visible(False)
    fig.suptitle("图 3  12 类测试集混淆矩阵（seed=42，按行归一化）", fontsize=12, fontweight="bold")
    fig.subplots_adjust(top=.85, bottom=.12, left=.06, right=.86, wspace=.25)
    colorbar_axis = fig.add_axes([.90, .19, .015, .61])
    fig.colorbar(image, cax=colorbar_axis, label="按真实类别归一化的比例")
    save(fig, "05_confusion_matrices")

    fig, axes = plt.subplots(1, 2, figsize=(10.8, 4.2))
    values = [probes["explicit_token_coverage"] * 100, probes["explicit_type_coverage"] * 100]
    bars = axes[0].bar(["按词频加权（token）", "不同词形（type）"], values, color=[COLORS[0], COLORS[1]], width=.55)
    axes[0].bar_label(bars, fmt="%.2f%%", padding=4)
    axes[0].set(ylim=(0, 110), ylabel="显式词表覆盖率（%）", title="高频词覆盖好，长尾词形仍稀疏")
    labels = [o["word"] for o in probes["oov_examples"]]
    values = [o["trained_bucket_fraction"] * 100 for o in probes["oov_examples"]]
    bars = axes[1].barh(labels, values, color=COLORS[2])
    axes[1].bar_label(bars, fmt="%.1f%%", padding=3)
    axes[1].set(xlim=(0, 115), xlabel="子词落入训练过的哈希桶的比例（%）", title="4 个构造的 OOV 整词示例")
    axes[1].invert_yaxis()
    fig.suptitle("附图 C  词表覆盖率与未登录词子词统计", fontsize=12, fontweight="bold")
    fig.tight_layout()
    save(fig, "06_oov_coverage")


def report(data, train, cls, probes, env):
    train_by_name = {t["name"]: t for t in train}
    ab = [a for a in cls["ablations"] if a["seed"] == 42]
    ft = train_by_name["ft_sg100"]
    w2v = train_by_name["w2v_sg100"]
    selected = cls["selected_ft"]
    main = cls["tasks"]["12"][0]
    best = max(METHODS, key=lambda m: summary(cls, "12", m, "macro_f1")[0])
    base_f1 = summary(cls, "12", "FastText-Mean", "macro_f1")[0]
    tf_f1 = summary(cls, "12", "TF-IDF", "macro_f1")[0]
    weighted_f1 = summary(cls, "12", "FastText-TFIDF", "macro_f1")[0]
    corpus_stats = read(ROOT / "data/processed/corpus_stats.json")
    file_counts = table(["月份", "原始文章记录", "筛选后文章"], [
        [f"1998-{month[4:]}", number, data["retained_articles_by_month"][month]]
        for month, number in data["raw_articles_by_month"].items()])
    task_rows = []
    for task, runs in cls["tasks"].items():
        run = runs[0]
        task_rows.append([task, "、".join(run["labels"]), *[run["sizes"][k] for k in ("train", "valid", "test")]])
    split_table = table(["类别数", "版面标签", "训练文章", "验证文章", "测试文章"], task_rows)
    time_rows = []
    for t in train:
        time_rows.append([NAMES[t["name"]], t["vocab"], f"{t['build_vocab_seconds']:.2f}",
                          f"{t['train_seconds']:.2f}", f"{t['total_seconds']:.2f}",
                          f"{t['array_bytes']/2**20:.2f}"])
    costs = table(["模型", "词表大小", "建词表/s", "5轮训练/s", "合计/s", "主要数组/MiB"], time_rows)
    metric_rows, acc_rows, csv_rows = [], [], []
    for method in METHODS + ["Majority"]:
        means, accs = [], []
        for task in ("2", "3", "5", "12"):
            m, s = summary(cls, task, method, "macro_f1")
            a, astd = summary(cls, task, method, "accuracy")
            means.append(f"{m*100:.2f} ± {s*100:.2f}")
            accs.append(f"{a*100:.2f}")
            csv_rows.append([method, task, m, s, a, astd])
        metric_rows.append([method, *means])
        acc_rows.append([method, *accs])
    macro_table = table(["表示方法", "2类", "3类", "5类", "12类"], metric_rows)
    accuracy_table = table(["表示方法", "2类", "3类", "5类", "12类"], acc_rows)
    export_csv(OUT / "main_results.csv", ["method", "classes", "macro_f1_mean", "macro_f1_std", "accuracy_mean", "accuracy_std"], csv_rows)
    export_csv(OUT / "training_costs.csv", ["model", "vocabulary", "build_seconds", "train_seconds", "total_seconds", "array_MiB"], time_rows)
    abrows = []
    for a in ab:
        t = train_by_name[a["model"]]
        p = t["params"]
        abrows.append([NAMES[a["model"]], "SG" if p["sg"] else "CBOW", p["vector_size"],
                       p["window"], f"{p['min_n']}–{p['max_n']}", p["bucket"],
                       f"{a['valid_macro_f1']*100:.2f}"])
    ablation = table(["配置", "算法", "维数", "窗口", "字符n-gram", "bucket", "验证Macro-F1/%"], abrows)
    export_csv(OUT / "ablation.csv", ["configuration", "algorithm", "dimensions", "window", "char_ngram", "bucket", "validation_macro_f1_percent"], abrows)
    neighbors = []
    for word in ("经济", "改革", "足球", "北京"):
        item = probes["nearest"][word]
        neighbors.append([word, "、".join(f"{w}（{s:.3f}）" for w, s in item["Word2Vec"][:3]),
                          "、".join(f"{w}（{s:.3f}）" for w, s in item["FastText"][:3])])
    neighbor_table = table(["查询词", "Word2Vec 前3个近邻", "FastText 前3个近邻"], neighbors)
    oovrows = [[o["word"], "否" if not o["in_vocab"] else "是", "不可直接查得", "可构造",
                f"{100*o['trained_bucket_fraction']:.1f}%", o["nearest"][0][0]] for o in probes["oov_examples"]]
    oovtable = table(["构造的整词", "进入训练词表", "Word2Vec", "FastText", "训练桶接触率", "FT第一近邻"], oovrows)
    perclassrows = []
    for label in main["labels"]:
        a = main["methods"]["TF-IDF"]["per_class"][label]
        b = main["methods"]["FastText-Selected"]["per_class"][label]
        perclassrows.append([label, int(a["support"]), percent(a["f1-score"]), percent(b["f1-score"])])
    perclass = table(["版面", "测试篇数", "TF-IDF F1/%", "验证集选定FT F1/%"], perclassrows)
    export_csv(OUT / "per_class_seed42.csv", ["page", "test_samples", "TFIDF_F1_percent", "selectedFT_F1_percent"], perclassrows)
    errors = sorted([p for p in main["methods"]["FastText-Selected"]["predictions"] if p["truth"] != p["prediction"]],
                    key=lambda p: -p["confidence"])
    errors = errors[:4]
    error_table = table(["文章编号", "首段/标题", "真实版面", "预测版面"],
                        [[e["article_id"], re.sub(r"\s+", "", e["title"])[:55].replace("(", "（").replace(")", "）").replace(":", "："),
                          e["truth"], e["prediction"]] for e in errors])
    cbow = next(a for a in ab if a["model"] == "ft_cbow100")
    sg = next(a for a in ab if a["model"] == "ft_sg100")
    dim50 = next(a for a in ab if a["model"] == "ft_sg50")
    dim200 = next(a for a in ab if a["model"] == "ft_sg200")
    bucket20 = next(a for a in ab if a["model"] == "ft_bucket20k")
    ngram36 = next(a for a in ab if a["model"] == "ft_ngram36")
    selectedrows = table(["划分随机种子", "该次验证集选定FT配置"],
                         [[seed, NAMES[name]] for seed, name in cls["selected_ft_by_seed"].items()])
    max_error = max(x["max_abs_error"] for x in probes["vector_composition_checks"])
    training_total = sum(t["total_seconds"] for t in train)
    reqs = "\n".join(f"{k}=={v}" for k, v in env["packages"].items()) + "\n"
    (ROOT / "requirements-experiment.txt").write_text(reqs, encoding="utf-8")

    from formal_report import render
    text = render(data, train, cls, probes, env, dict(
        split_table=split_table, costs=costs, macro_table=macro_table,
        accuracy_table=accuracy_table, ablation=ablation,
        neighbor_table=neighbor_table, oovtable=oovtable,
        perclass=perclass, error_table=error_table,
    ))
    # Keep a native-table, no-image source for the Piazza rich-text generator.
    submission = re.sub(r"(?m)^!\[[^]]*\]\([^)]+\)\s*\n", "", text)
    submission = re.sub(r"\$\$\s*([\s\S]*?)\s*\$\$",
                        lambda match: "$$" + re.sub(r"\s+", " ", match.group(1)).strip() + "$$",
                        submission)
    submission = re.sub(r"\n{3,}", "\n\n", submission).strip() + "\n"
    (OUT / "report_submission.md").write_text(submission, encoding="utf-8")
    from layout_report import apply_layout
    text = apply_layout(text, OUT)
    report_path = OUT / "Gensim_FastText_实验报告.md"
    report_path.write_text(text.strip() + "\n", encoding="utf-8")
    return report_path


def main():
    data = read(ROOT / "data/experiment/manifest.json")
    train = read(OUT / "training.json")
    cls = read(OUT / "classification.json")
    probes = read(OUT / "probes.json")
    env = read(OUT / "environment.json")
    assert len(cls["ablations"]) == 21
    assert set(cls["selected_ft_by_seed"]) == {"42", "43", "44"}
    assert all(len(runs) == 3 for runs in cls["tasks"].values())
    plots(data, train, cls, probes)
    path = report(data, train, cls, probes, env)
    # Portable report package: relative image links remain valid on extraction.
    bundle = ROOT / "Gensim_FastText_报告与图表.zip"
    with zipfile.ZipFile(bundle, "w", compression=zipfile.ZIP_DEFLATED) as archive:
        for p in OUT.rglob("*"):
            if p.is_file():
                archive.write(p, p.relative_to(OUT))
        for name in ("fetch_external.py", "prepare_corpus.py", "run_experiments.py", "build_report.py", "formal_report.py", "layout_report.py", "requirements-experiment.txt"):
            archive.write(ROOT / name, f"reproduce/{name}")
        for p in (ROOT / "data/experiment/manifest.json", ROOT / "data/external/source.json"):
            archive.write(p, f"provenance/{p.name}")
    print(path)
    print(bundle)
    print(f"report_chars={len(path.read_text(encoding='utf-8'))}, charts={len(list(FIG.glob('*.png')))}")


if __name__ == "__main__":
    main()
