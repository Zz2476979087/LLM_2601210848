# Gensim 与 FastText 实验代码

本包仅包含代码、依赖清单和运行说明，不包含语料、模型、实验结果或报告成品。

## 准备数据

将人民日报压缩包中的文本文件解压至项目的 data/raw/ 目录。外部 THUCNews 标题由 fetch_external.py 下载并验证。

## 安装与运行

使用 Python 3.12，在解压后的项目目录执行：

```powershell
py -3.12 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements-experiment.txt
.\.venv\Scripts\python.exe run_all.py
```

完整流程执行数据清洗、词向量训练、分类评估和报告生成。代码默认使用 Windows 的微软雅黑绘制辅助图表。

已有实验结果时，仅重建稿件：

```powershell
.\.venv\Scripts\python.exe run_all.py --report-only
```

程序生成的语料、模型和结果分别位于 data/、models/ 和 results/。分类标签使用原始版面号，按文章划分数据；验证集选择参数，测试集评估结果。
