"""Create native HTML tables for copying rendered content to Piazza Rich Text.

Formulas stay as literal $$...$$ text for Piazza to render after paste.
Open the output in a browser and copy the rendered body, not the HTML source.
"""
import html
import re
from pathlib import Path


def inline(text):
    text = html.escape(text)
    text = re.sub(r"\*\*(.+?)\*\*", r"<strong>\1</strong>", text)
    text = re.sub(r"`([^`]+)`", r"<code>\1</code>", text)
    text = re.sub(r"\[([^]]+)\]\((https?://[^)]+)\)", r'<a href="\2">\1</a>', text)
    return text


def render(source):
    blocks = []
    table_count = 0
    for block in re.split(r"\n\s*\n", source.strip()):
        if block.startswith("|"):
            rows = [[cell.strip() for cell in line.strip().strip("|").split("|")]
                    for line in block.strip().splitlines()]
            rows.pop(1)
            assert len({len(row) for row in rows}) == 1
            parts = ['<table style="border-collapse:collapse;width:100%;margin:14px 0;font-size:13px;" border="1" cellpadding="7">']
            for index, row in enumerate(rows):
                tag = "th" if index == 0 else "td"
                shade = "background-color:#eaf0f5;" if index == 0 else ""
                parts.append("<tr>" + "".join(
                    f'<{tag} style="border:1px solid #8b97a2;padding:7px;{shade}">{inline(cell)}</{tag}>'
                    for cell in row) + "</tr>")
            parts.append("</table>")
            blocks.append("\n".join(parts))
            table_count += 1
        elif block.startswith("$$"):
            # Do not render MathJax locally: copying the literal delimiters lets
            # Piazza detect equations rather than copying generated math HTML.
            blocks.append('<p style="margin:16px 0;">' + html.escape(block) + "</p>")
        elif re.match(r"^#{1,3}\s", block):
            match = re.match(r"^(#{1,3})\s+(.+)$", block)
            level = len(match.group(1))
            blocks.append(f'<h{level}>{inline(match.group(2))}</h{level}>')
        elif re.match(r"^\d+\.\s", block):
            rows = [re.sub(r"^\d+\.\s*", "", line) for line in block.splitlines()]
            blocks.append("<ol>" + "".join("<li>" + inline(row) + "</li>" for row in rows) + "</ol>")
        else:
            blocks.append("<p>" + inline(block).replace("\n", " ") + "</p>")
    assert table_count == 9
    return """<!doctype html>
<html lang="zh-CN"><head><meta charset="utf-8">
<title>人民日报 FastText 报告——复制到 Piazza 富文本编辑器</title>
<style>body{max-width:1000px;margin:30px auto;padding:0 20px;font:16px/1.8 'Microsoft YaHei',sans-serif;color:#222;background:white}h1{font-size:26px}h2{font-size:21px;margin-top:28px}h3{font-size:18px}code{font-family:Consolas,monospace}p{margin:12px 0}th{text-align:left}</style>
</head><body>
""" + "\n".join(blocks) + "\n</body></html>\n"


def main():
    root = Path(__file__).resolve().parent
    source = (root / "results/report_submission.md").read_text(encoding="utf-8")
    source = re.sub(r"\$\$\s*([\s\S]*?)\s*\$\$", lambda match: "$$" + re.sub(r"\s+", " ", match.group(1)).strip() + "$$", source)
    assert "```" not in source and "![" not in source
    assert not re.search(r"(?<!\$)\$(?!\$)", source)
    target = root / "results/piazza_rich_text.html"
    target.write_text(render(source), encoding="utf-8")
    print(target)


if __name__ == "__main__":
    main()
