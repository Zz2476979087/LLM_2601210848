"""Generate the submission report from the recorded experiment results."""
import numpy as np


def render(data, train, cls, probes, env, tables):
    meta = {row["name"]: row for row in train}
    ab = {row["model"]: row for row in cls["ablations"] if row["seed"] == 42}

    def table(headers, rows):
        return "\n".join([
            "| " + " | ".join(headers) + " |",
            "| " + " | ".join("---" for _ in headers) + " |",
            *("| " + " | ".join(map(str, row)) + " |" for row in rows),
        ])

    methods = ["TF-IDF", "Word2Vec-Mean", "FastText-Mean", "FastText-TFIDF", "FastText-Selected"]
    rows = []
    for method in methods:
        row = [method]
        for task in ("2", "3", "5", "12"):
            values = [r["methods"][method]["macro_f1"] * 100 for r in cls["tasks"][task]]
            row.append(f"{np.mean(values):.2f} ± {np.std(values,ddof=1):.2f}")
        accuracy = np.mean([r["methods"][method]["accuracy"] * 100 for r in cls["tasks"]["12"]])
        row.append(f"{accuracy:.2f}")
        rows.append(row)
    main = table(["表示方法", "2 类 F1", "3 类 F1", "5 类 F1", "12 类 F1", "12 类 Accuracy"], rows)
    cost_rows = []
    for name, label in [("w2v_sg100","Word2Vec SG100"),("ft_sg100","FastText SG100"),
                        ("ft_cbow100","FastText CBOW100"),("ft_sg200","FastText SG200")]:
        item = meta[name]
        cost_rows.append([label, f"{item['total_seconds']:.2f}", f"{item['array_bytes']/2**20:.2f}"])
    costs = table(["模型", "建词表与训练/s", "主要数组/MiB"], cost_rows)
    parameters = []
    for name, label in [("ft_sg100","基准：SG，100维，窗口5，子词2—4，10万桶"),
                        ("ft_cbow100","改为 CBOW"),("ft_sg50","维数改为 50"),
                        ("ft_sg200","维数改为 200"),("ft_window10","窗口改为 10"),
                        ("ft_ngram36","子词长度改为 3—6"),("ft_bucket20k","桶数改为 2万")]:
        parameters.append([label, f"{ab[name]['valid_macro_f1']*100:.2f}", f"{meta[name]['array_bytes']/2**20:.2f}"])
    parameter_table = table(["配置", "验证 Macro-F1/%", "主要数组/MiB"], parameters)
    perclass = cls["tasks"]["12"][0]["methods"]
    class_table = table(["版面", "TF-IDF F1/%", "FastText F1/%"], [
        [page, f"{perclass['TF-IDF']['per_class'][page]['f1-score']*100:.2f}",
         f"{perclass['FastText-Selected']['per_class'][page]['f1-score']*100:.2f}"]
        for page in ("06","07","08","09","11","12")])
    return rf"""# 《人民日报》文本向量表示与 FastText 分类实验报告

## 一、实验目的与摘要

本实验使用 Gensim 训练 Word2Vec 和 FastText，完成新闻文本的向量化表示与分类，并与 TF-IDF 进行比较。分类标签采用《人民日报》原始版面号，类别数量由 2 类逐步增加到 3、5、12 类，同时考察向量维数、窗口和字符子词等参数的影响。

结果显示，12 类任务中 TF-IDF 的平均 Macro-F1 为 **52.10%**，FastText 基准模型为 **44.94%**，调整窗口后为 **45.96%**。FastText 可以通过子词共享处理未登录整词，但平均词向量对文章判别信息的保留仍有不足。

## 二、数据集与预处理

### 2.1 数据来源

**基础语料：** 选取 60,000 条去重后的 THUCNews 新闻标题，去掉类别标签；另从《人民日报》1998 年 2—6 月语料中，每月抽取约 200,000 个词次。合并后共 105,407 个句子或标题，包含 1,546,769 个词次，用于无监督词向量训练。

**分类语料：** 使用《人民日报》1998 年 1 月语料。按照文章编号合并后得到 3,132 条文章记录，经筛选保留 3,034 篇。类别标签取自原始版面号，一月份文章不参与词向量训练。

### 2.2 预处理方法

1. **编码处理：** 按 GB18030 读取原始文本，兼容 GBK 编码，并记录无法解码的字节。
2. **去除标记：** 删除行首编号和 `{{shang5}}` 等拼音注释，统一全角与半角字符。
3. **分词处理：** 人民日报保留原有分词，THUCNews 标题使用 jieba 分词，过滤纯标点并保留有意义的单字词。
4. **文章重建：** 根据日期、版面和篇号合并同一篇文章的各段，避免将单个段落误作完整文章。
5. **质量筛选：** 过滤少于 30 个词的记录及部分简短图片、广告内容，结合文本哈希与词 5-gram 相似度检查重复文章。

这些处理可以减少格式标记造成的词形分裂和无效词项，使词频统计与上下文学习集中在正文内容上。

### 2.3 数据划分

按照版面标签分层，训练集、验证集和测试集的比例约为 70%、15% 和 15%。以完整文章为划分单位。随机种子为 42 时，各任务的样本数量如下。

| 类别数 | 版面标签 | 训练集 | 验证集 | 测试集 |
|---|---|---:|---:|---:|
| 2 | 01、06 | 426 | 91 | 92 |
| 3 | 01、02、06 | 747 | 159 | 161 |
| 5 | 01、02、03、04、06 | 1,275 | 272 | 275 |
| 12 | 01—12 | 2,123 | 455 | 456 |

采用 42、43、44 三个随机种子重复划分，共用相同的预训练词向量；每次均使用相应验证集选择参数，再在测试集上评估。

## 三、表示方法与训练开销

Word2Vec 基准采用 Skip-gram 与负采样；FastText 在整词参数之外引入字符 n-gram 参数。文章分别使用平均词向量与 TF-IDF 加权平均表示：

$$
\mathbf{{x}}_d=\frac{{1}}{{|d'|}}\sum_{{w\in d'}}\mathbf{{v}}_w,
\qquad
\mathbf{{x}}_d^{{\mathrm{{weighted}}}}
=\frac{{\sum_{{w\in d}}a_{{w,d}}\mathbf{{v}}_w}}{{\sum_{{w\in d}}a_{{w,d}}}}.
$$

其中，Word2Vec 跳过无法查得的词，FastText 允许子词推断；加权方案的词表与 IDF 由分类训练集估计。文章向量进行 L2 归一化，分类器统一采用逻辑回归，设置类别权重，并根据验证集从以下范围选择正则化参数：

$$C\in\{{0.1,1,10\}}$$

基准参数为 **100 维、窗口 5、最低词频 3、负样本数 5、训练 5 轮**；FastText 字符长度为 2—4，桶数为 100,000。各模型词表均为 **37,837 个词**。实验环境为 i9-14900KF、Python {env['python']}、Gensim {env['packages']['gensim']}、scikit-learn {env['packages']['scikit-learn']}，使用 4 个 CPU 线程。

{costs}

基准 FastText 的主要数组内存是 Word2Vec 的 **2.81 倍**，增量来自子词参数和合成向量；200 维模型的内存约为 100 维的两倍。子词矩阵存储近似为：

$$M_{{\mathrm{{ngram}}}}\approx B\times D\times4\ \mathrm{{bytes}}$$

因此，维数和桶数会直接影响成本。上表时间为单次测量，数组内存不包含全部索引、字典与临时缓冲。

## 四、分类结果与参数分析

### 4.1 不同表示方法的分类效果

Macro-F1 对各类别的 F1 等权平均：

$$
F_1^{{\mathrm{{macro}}}}=\frac{{1}}{{K}}\sum_{{k=1}}^K\frac{{2P_kR_k}}{{P_k+R_k}}.
$$

下表 F1 为三次划分的均值 ± 样本标准差，Accuracy 为三次均值，单位均为 %。

{main}

Mean 表示平均词向量，TFIDF 表示加权平均；Selected 表示由验证集选择的配置。三次划分均选中 100 维、窗口为 10 的 Skip-gram 模型。

![图1 不同表示方法的分类结果](figures/02_classification_comparison.png)

**TF-IDF 的优势主要体现在词项区分能力。** 版面分类与专名、栏目用语和专业词汇有关，TF-IDF 保留了这些独立特征。平均词向量将整篇文章压缩到固定维度，容易削弱少量关键字词的影响。12 类任务中，TF-IDF 比 FastText 基准高 **7.16 个百分点**。

**子词共享没有在所有任务中转化为分类优势。** FastText 在 12 类任务中略优于 Word2Vec，但在 3 类和 5 类中略低。其收益受到词形共享质量、文章聚合方式及标签特点共同影响。TF-IDF 加权平均也未改善本次结果，12 类 Macro-F1 为 **43.76%**；加权既可能突出有效词，也可能放大低频实体和不稳定表示。

**类别增加后，版面间内容交叉加重。** TF-IDF 的 Macro-F1 从 2 类的 95.28% 降至 12 类的 52.10%，FastText 则从 91.30% 降至 44.94%。新增版面包含更多主题相近的新闻、评论与专题，细粒度区分更加困难。

### 4.2 FastText 参数实验

在随机种子为 42 的 12 类验证集上，每次改变一个训练因素，得到以下结果。

{parameter_table}

![图2 FastText 参数实验](figures/04_parameter_ablation.png)

50 维增至 100 维后效果改善，但 200 维没有继续提高；窗口增至 10 后验证 Macro-F1 提高 **0.52 个百分点**，训练时间从 8.57 s 增至 11.62 s。字符长度 2—4 优于 3—6，与当前中文短词的共享结构相适应。桶数降至 20,000 后，数组内存减少约 **37.4%**，分数下降 **0.68 个百分点**，体现了存储开销与哈希碰撞之间的折中。

## 五、表示效果与错误案例

### 5.1 相似词与未登录词

以下为两个 100 维 Skip-gram 模型的前三个近邻，括号内为余弦相似度。

{tables['neighbor_table']}

Word2Vec 将“北京”与其他城市联系起来，更侧重相似上下文；FastText 的近邻包含“北京地铁、北京晚报”，体现了共享字片段的作用。“经济域”“北京华”等少见词形也进入较近位置，说明部分近邻同时受到词频、分词和词形重合的影响。

基础词表覆盖一月语料 **94.28% 的词次**，但只覆盖 **43.28% 的不同词形**。对四个未进入词表的复合词进行整词查询，结果如下。

{tables['oovtable']}

训练桶接触率表示子词映射的桶中曾被训练词表使用的比例，包含共享子词与哈希碰撞。“足球世界杯预选赛”能够关联到“足协杯赛”，而“金融科技创新”的第一近邻为“熔盛”。这说明 OOV 向量可用性提高后，语义质量仍受子词训练和组合方式影响。

### 5.2 分类混淆与错误样例

12 类、随机种子为 42 的测试集中，部分版面的 F1 如下。FastText 使用验证集选定的窗口为 10 的模型。

{class_table}

![图3 十二类测试集混淆矩阵](figures/05_confusion_matrices.png)

第 06—08 版识别较好，第 09、11 版混淆明显。按错误预测置信度排序，选取以下四例。

{tables['error_table']}

前三篇均含明显体育内容，实际位于第 02、05、04 版，却被统一预测为第 08 版；第四篇涉及公安执勤和群众纠纷，被预测为第 03 版。这些错误表明，文章主题与实际版面并非一一对应。平均词向量能反映显著主题，但较难表示栏目属性、体裁及编辑安排。

## 六、论文与 Gensim 实现对照

[FastText 论文](https://arxiv.org/abs/1607.04606)将 Skip-gram 的整词表示扩展为字符 n-gram 参数的组合，使低频词从其他词的相同子词中获得统计支持。Gensim 4.4.0 的主要实现关系如下。

| 算法环节 | 对应实现 | 作用 |
| --- | --- | --- |
| 字符子词 | `compute_ngrams_bytes`、`ft_ngram_hashes` | 提取带边界的字符片段并映射到哈希桶 |
| 参数存储 | `vectors_vocab`、`vectors_ngrams` | 分别保存整词与子词参数 |
| 向量查询 | `adjust_vectors`、`get_vector` | 合成已登录词和未登录词向量 |
| 核心训练 | `train_batch_any`、`fasttext_fast_sentence_sg_neg` | 准备批次并执行负采样更新 |

已登录词的查询向量为：

$$
\mathbf{{v}}_w=
\frac{{\mathbf{{z}}_w+\sum_{{g\in G(w)}}\mathbf{{z}}_{{h(g)}}}}{{1+|G(w)|}},
$$

未登录词则使用子词桶向量的平均值。训练阶段另有输入缩放与参数更新步骤，需要与查询时的合成分别理解。实验手工组合“经济、足球、北京”的参数，与查询结果的最大绝对误差为：

$$1.19\times10^{{-7}}$$

模型保存、加载后的向量差为 0。

周边参数中，`min_count` 决定显式训练词表，`sample` 控制高频词下采样，`negative` 控制噪声样本数，`shrink_windows` 调整有效窗口；学习率与训练进度共同决定更新幅度。实现对应于 [Gensim 4.4.0 源码](https://github.com/piskvorky/gensim/tree/4.4.0/gensim/models)。

## 七、实验思考与讨论

**词级语义表示不等于完整的文章表示。** FastText 改善了词形共享和未登录词表示，但简单平均忽略词序与段落主次关系，限制了下游分类效果。TF-IDF 在本次任务中的优势说明，稀疏词项特征仍具有较强的判别能力。

**参数增加需要相应的数据支持。** 更高维数和更大桶数会增加存储成本，验证成绩却未必同步提高。当前结果支持在验证效果与计算成本之间选择适当配置，而非单纯扩大模型。

**版面分类还受到编辑编排的影响。** 后续可以分别表示标题与正文，比较句向量、段落向量或保留词序的模型。本实验三次结果主要反映样本划分波动，词向量未独立重训；外部标题较短、两种语料分词来源不同，也可能影响表示质量。
"""
