"""Optional real SRILM comparison on the same cleaned full training split."""
import json
import re
import subprocess
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def run():
    sources = sorted((ROOT / "vendor").glob("SRILM-*"))
    executable = sources[0] / "bin/i686-m64/ngram-count"
    query = sources[0] / "bin/i686-m64/ngram"
    if not executable.exists() or not query.exists():
        raise FileNotFoundError("SRILM ngram-count/ngram were not built")
    folder = ROOT / "models/srilm"
    folder.mkdir(parents=True, exist_ok=True)
    results = []
    for n in (2, 3, 5):
        arpa = folder / ("order{}.arpa".format(n))
        cmd = [str(executable), "-order", str(n), "-text", str(ROOT / "data/processed/train.txt"),
               "-lm", str(arpa), "-kndiscount", "-interpolate", "-unk"]
        for j in range(1, n + 1):
            cmd += ["-gt{}min".format(j), "1"]
        start = time.perf_counter()
        with (ROOT / "logs/srilm{}.log".format(n)).open("w") as output:
            subprocess.run(cmd, stdout=output, stderr=output, check=True)
        seconds = time.perf_counter() - start
        evaluations = {}
        for split in ("valid", "test"):
            command = [str(query), "-order", str(n), "-lm", str(arpa), "-ppl",
                       str(ROOT / "data/processed" / (split + ".txt")), "-unk"]
            p = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, check=True)
            (ROOT / "logs" / ("srilm{}_{}.log".format(n, split))).write_text(p.stdout)
            match = re.search(r"ppl=\s*([0-9.eE+-]+)", p.stdout)
            if not match:
                raise ValueError("Could not parse SRILM perplexity")
            evaluations[split] = {"ppl": float(match.group(1)), "raw_output": p.stdout}
        results.append({"order": n, "seconds": seconds, "arpa_bytes": arpa.stat().st_size,
                        "command": cmd, "evaluations": evaluations})
        (ROOT / "results/srilm_training.json").write_text(json.dumps(results, indent=2))
        print("SRILM n={} seconds={:.2f} test_ppl={:.3f}".format(n, seconds, evaluations["test"]["ppl"]), flush=True)


if __name__ == "__main__":
    run()
