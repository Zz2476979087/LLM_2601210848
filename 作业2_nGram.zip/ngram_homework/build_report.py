"""Build a medium-length report, native Piazza tables, and inline result figures."""
import base64
import csv
import html
import json
import re
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib import font_manager
import numpy as np

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "results"
FIG = OUT / "figures"


def read(path):
    return json.loads(path.read_text(encoding="utf-8"))


def table(headers, rows):
    def cell(value):
        return str(value).replace("|", "／").replace("\n", " ")
    return "\n".join(["| " + " | ".join(map(cell, headers)) + " |",
                       "| " + " | ".join("---" for _ in headers) + " |"] +
                      ["| " + " | ".join(map(cell, row)) + " |" for row in rows])


def plot_results(kenlm_train, stupid_train, evaluation):
    FIG.mkdir(exist_ok=True)
    font = Path("C:/Windows/Fonts/msyh.ttc")
    if not font.exists():
        font = Path("/mnt/c/Windows/Fonts/msyh.ttc")
    if font.exists():
        font_manager.fontManager.addfont(str(font))
        plt.rcParams["font.family"] = "Microsoft YaHei"
    plt.rcParams.update({"axes.unicode_minus": False, "font.size": 10,
                         "axes.spines.top": False, "axes.spines.right": False})
    orders = list(range(1, 11))
    fig, ax = plt.subplots(figsize=(9.5, 4.1))
    ax.plot(orders, [x["seconds"] for x in kenlm_train], "o-", label="KenLM：独立训练", color="#176B87")
    ax.plot(orders, [x["cumulative_seconds"] for x in stupid_train], "s-", label="Stupid Backoff：累计计数", color="#C57932")
    ax.set(xlabel="模型阶数", ylabel="时间 / s", xticks=orders,
           title="训练开销随阶数变化（包含各自模型写出）")
    ax.legend()
    ax.grid(alpha=.15)
    fig.tight_layout()
    fig.savefig(FIG / "01_training.png", dpi=200)
    plt.close(fig)
    test = [x["test"]["ppl"] for x in evaluation]
    valid = [x["valid"]["ppl"] for x in evaluation]
    fig, axes = plt.subplots(1, 2, figsize=(11.2, 4))
    for ax, begin in zip(axes, [0, 2]):
        ax.plot(orders[begin:], test[begin:], "o-", label="测试集", color="#176B87")
        ax.plot(orders[begin:], valid[begin:], "s--", label="验证集", color="#C57932")
        ax.set(xlabel="模型阶数", ylabel="Perplexity", xticks=orders[begin:])
        ax.grid(alpha=.15)
        ax.legend()
    axes[0].set_yscale("log")
    axes[0].set_title("1—10 阶：对数纵轴")
    axes[1].set_title("3—10 阶：局部变化")
    fig.tight_layout()
    fig.savefig(FIG / "02_perplexity.png", dpi=200)
    plt.close(fig)
    fig, ax = plt.subplots(figsize=(10, 4.3))
    selected = [kenlm_train[i - 1] for i in (3, 6, 10)]
    left = np.zeros(3)
    labels = ["计数与排序", "调整计数", "初始概率", "插值处理", "ARPA 写出"]
    for index, (label, color) in enumerate(zip(labels, ["#176B87", "#57998A", "#C57932", "#9C78AD", "#D85B67"])):
        values = np.array([x["phases"][index]["seconds"] for x in selected])
        ax.barh(["3 阶", "6 阶", "10 阶"], values, left=left, label=label, color=color)
        left += values
    ax.set(xlabel="日志阶段时长 / s", title="KenLM 训练阶段分解（按日志阶段切换时刻估算）")
    ax.legend(ncol=3, loc="lower right", fontsize=8)
    ax.grid(axis="x", alpha=.15)
    ax.set_axisbelow(True)
    fig.tight_layout()
    fig.savefig(FIG / "03_phases.png", dpi=200)
    plt.close(fig)


def inline(text):
    value = html.escape(text)
    value = re.sub(r"\*\*(.+?)\*\*", r"<strong>\1</strong>", value)
    value = re.sub(r"`([^`]+)`", r"<code>\1</code>", value)
    value = re.sub(r"\[([^]]+)\]\((https?://[^)]+)\)", r'<a href="\2">\1</a>', value)
    return value


def rich_text(markdown):
    parts = []
    for block in re.split(r"\n\s*\n", markdown.strip()):
        if block.startswith("|"):
            rows = [[x.strip() for x in line.strip().strip("|").split("|")] for line in block.splitlines()]
            rows.pop(1)
            lines = ['<table border="1" cellpadding="7" style="border-collapse:collapse;width:100%;font-size:13px;margin:15px 0;">']
            for index, row in enumerate(rows):
                tag = "th" if index == 0 else "td"
                lines.append("<tr>" + "".join('<{} style="border:1px solid #9aa6b1;padding:7px;">{}</{}>'.format(tag, inline(x), tag) for x in row) + "</tr>")
            lines.append("</table>")
            parts.append("\n".join(lines))
        elif re.fullmatch(r"!\[[^]]*\]\([^)]+\)", block):
            match = re.fullmatch(r"!\[([^]]*)\]\(([^)]+)\)", block)
            image = OUT / match.group(2)
            data = base64.b64encode(image.read_bytes()).decode("ascii")
            parts.append('<p><img alt="{}" style="max-width:100%;height:auto;" src="data:image/png;base64,{}"></p>'.format(html.escape(match.group(1)), data))
        elif block.startswith("#"):
            match = re.match(r"^(#{1,3})\s+(.+)$", block)
            level = len(match.group(1))
            parts.append("<h{0}>{1}</h{0}>".format(level, inline(match.group(2))))
        elif block.startswith("$$"):
            parts.append("<p>" + html.escape(block) + "</p>")
        else:
            parts.append("<p>" + inline(block).replace("\n", " ") + "</p>")
    return '<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><title>人民日报 n-gram 实验报告</title><style>body{max-width:1040px;margin:30px auto;padding:0 20px;font:16px/1.85 "Microsoft YaHei",sans-serif;color:#222}h1{font-size:26px}h2{font-size:21px;margin-top:30px}h3{font-size:18px}th{background:#eaf0f5}code{font-family:Consolas,monospace}</style></head><body>' + "\n".join(parts) + "</body></html>"


def main():
    data = read(ROOT / "data/processed/data_stats.json")
    k_all = read(OUT / "kenlm_training.json")
    ken = [x for x in k_all if x["label"] != "order5_pruned"]
    stupid = read(OUT / "stupid_training.json")
    evaluation = read(OUT / "evaluation.json")
    generation = read(OUT / "generation.json")
    binary = read(OUT / "binary_comparison.json")
    pruned = read(OUT / "pruning_evaluation.json")
    norms = read(OUT / "normalization.json")
    env = read(OUT / "environment.json")
    sri = read(OUT / "srilm_training.json") if (OUT / "srilm_training.json").exists() else []
    assert len(ken) == len(stupid) == len(evaluation) == 10
    plot_results(ken, stupid, evaluation)
    split_table = table(["集合", "文章数", "句子数", "词次", "含句尾预测位置"], [
        [label, item["articles"], item["sentences"], item["tokens"], item["prediction_positions_with_eos"]]
        for label, item in (("训练", data["splits"]["train"]), ("验证", data["splits"]["valid"]), ("测试", data["splits"]["test"]))])
    results_rows = [[k["order"], "{:.2f}".format(k["seconds"]), "{:.2f}".format(s["seconds"]),
                     "{:.2f}".format(s["cumulative_seconds"]), "{:.2f}".format(e["test"]["ppl"]),
                     "{:.1f}".format(k["arpa_bytes"] / 2**20)] for k, s, e in zip(ken, stupid, evaluation)]
    main_table = table(["阶数", "KenLM/s", "SB本阶/s", "SB累计/s", "测试PPL", "ARPA/MiB"], results_rows)
    with (OUT / "main_results.csv").open("w", encoding="utf-8-sig", newline="") as file:
        writer = csv.writer(file)
        writer.writerow(["order", "kenlm_seconds", "stupid_order_seconds", "stupid_cumulative_seconds", "test_ppl", "arpa_MiB"])
        writer.writerows(results_rows)
    phase_table = table(["阶数", "计数排序/s", "调整计数/s", "初始概率/s", "插值处理/s", "ARPA写出/s"], [
        [n] + ["{:.2f}".format(p["seconds"]) for p in ken[n - 1]["phases"]] for n in (3, 6, 10)])
    sri_table = table(["阶数", "KenLM训练/s", "SRILM训练/s", "KenLM测试PPL", "SRILM测试PPL"], [
        [s["order"], "{:.2f}".format(ken[s["order"] - 1]["seconds"]), "{:.2f}".format(s["seconds"]),
         "{:.2f}".format(evaluation[s["order"] - 1]["test"]["ppl"]), "{:.2f}".format(s["evaluations"]["test"]["ppl"])] for s in sri]) if sri else "SRILM 构建未完成，本次不报告其训练成绩。"
    rank_rows = []
    for n in (2, 3, 5, 10):
        for method in ("KenLM", "StupidBackoff"):
            item = evaluation[n - 1]["ranking"][method]
            rank_rows.append([n, method, "{:.2f}".format(item["top1"] * 100),
                              "{:.2f}".format(item["top5"] * 100), "{:.3f}".format(item["mrr"])])
    rank_table = table(["阶数", "方法", "Top-1/%", "Top-5/%", "MRR"], rank_rows)
    binary_table = table(["5阶存储", "文件/MiB", "构建/s", "载入/s", "查询/微秒", "测试PPL"], [
        [b["kind"], "{:.1f}".format(b["bytes"] / 2**20), "{:.2f}".format(b["build_seconds"]),
         "{:.2f}".format(b["load_seconds"]), "{:.3f}".format(b["median_microseconds_per_query"]),
         "{:.2f}".format(b["test_ppl"])] for b in binary])
    pruning_training = next(k for k in k_all if k["label"] == "order5_pruned")
    prune_table = table(["5阶配置", "训练/s", "ARPA/MiB", "验证PPL", "测试PPL"], [
        ["不剪枝", "{:.2f}".format(ken[4]["seconds"]), "{:.1f}".format(ken[4]["arpa_bytes"] / 2**20),
         "{:.2f}".format(evaluation[4]["valid"]["ppl"]), "{:.2f}".format(evaluation[4]["test"]["ppl"])],
        ["3—5阶删除计数为1的组合", "{:.2f}".format(pruning_training["seconds"]),
         "{:.1f}".format(pruning_training["arpa_bytes"] / 2**20), "{:.2f}".format(pruned["valid"]["ppl"]), "{:.2f}".format(pruned["test"]["ppl"])]] )
    # Representative cases selected by configuration, not by output fluency.
    shown = []
    for x in generation:
        if x["model"] == "KenLM" and (x["order"] in (2, 3, 10) or x["order"] == 5):
            shown.append(x)
        elif x["model"] == "StupidBackoff" and x["order"] in (3, 5, 10):
            shown.append(x)
    generation_table = table(["方法/阶数", "采样参数", "新词数", "续写节选"], [
        ["{}/{}".format("KN" if x["model"] == "KenLM" else "SB", x["order"]),
         "greedy" if x["greedy"] else "T={},k={}".format(x["temperature"], x["top_k"]) + (",a={}".format(x["alpha"]) if x["model"] == "StupidBackoff" else ""),
         x["new_tokens"], x["continuation"][:100] + ("……" if len(x["continuation"]) > 100 else "")]
        for x in shown])
    norm_table = table(["历史", "KenLM概率和", "SB分数和"], [
        [" ".join(x["history"]), "{:.6f}".format(x["kenlm_probability_sum"]), "{:.6f}".format(x["stupid_score_sum"])] for x in norms])
    best = min(evaluation, key=lambda e: e["valid"]["ppl"])
    writer_share = ken[9]["phases"][4]["seconds"] / ken[9]["seconds"] * 100
    ppm5 = evaluation[4]["test"]["ppl"]
    ppm10 = evaluation[9]["test"]["ppl"]
    savings = (1 - pruning_training["arpa_bytes"] / ken[4]["arpa_bytes"]) * 100
    text = rf"""# 《人民日报》n-gram 语言模型训练与文本生成实验报告

## 一、实验目的与摘要

本实验以此前使用的 1998 年 1—6 月《人民日报》带音切分语料为对象，完成标签清理、词级 n-gram 建模、训练过程观察和文本续写。使用 KenLM 训练 1—10 阶 Modified Kneser–Ney 模型，以单机实现的 Stupid Backoff 作为计数与回退对照，并使用 SRILM 比较部分阶数的训练与困惑度。进一步考察阶数、剪枝、温度、top-k 和回退系数的影响。

训练使用全部训练划分，共 **{data['splits']['train']['sentences']:,} 句、{data['splits']['train']['tokens']:,} 个词次**。五阶与十阶 KenLM 的测试困惑度分别为 **{ppm5:.2f}** 和 **{ppm10:.2f}**，对应 ARPA 文件为 **{ken[4]['arpa_bytes']/2**20:.1f} MiB** 和 **{ken[9]['arpa_bytes']/2**20:.1f} MiB**。实验同时记录概率估计、存储结构和生成参数的差异，不将 Stupid Backoff 的未归一化分数用于计算困惑度。

## 二、语料清洗与数据划分

原始六个文件共 {data['audit']['raw_lines']:,} 行，其中 {data['audit']['nonempty_records']:,} 条为非空段落记录，按编号合并为 {data['raw_articles']:,} 篇文章。清洗去掉行首编号、{data['audit']['pronunciation_tags_removed']:,} 处拼音注释，并统一全半角。此副本主要是已分词的带音文本，未检出需要批量剥离的词性或实体后缀；清洗器仍兼容 `/n` 等词性与复合实体外层标签。正文标点保留，`t/h`、`kcal/h` 等单位不会按词性标签误删。

**为什么必须清理标签？** n-gram 直接统计词的表层共现。若保留注音，同一个词会被分成“上”和“上{{shang5}}”等不同词形；若保留文档编号，则会产生大量无语言意义的唯一词，污染句首上下文并增加稀疏性。词性与实体标签属于额外标注，混入正文后模型学到的将是标注串的分布，续写也可能输出这些标签。

去掉 6 条重复段落副本，并按清洗后的文章内容去除 {data['audit']['duplicate_articles_removed']} 篇重复记录，保留 {data['retained_articles']:,} 篇。以文章为单位随机划分，固定种子 42；在正文句末标点处分句，句子之间不拼接上下文。

{split_table}

词表仅由训练集建立，出现一次的词及留出集未登录词统一映射为 `<UNK>`。输入阶段使用大写写法避开估计器对小写保留符的限制；查询阶段 KenLM 将两种写法视为同一未知词，统计概率和时仅计一次。词表含句首、句尾及映射符号，共 **{data['vocabulary_size_with_specials']:,} 项**。训练集未抽样缩减，验证和测试集保持独立。

## 三、模型方法与实现

n-gram 以最近 n−1 个词近似完整历史，最大似然估计为：

$$P(w\mid h)=\frac{{c(h,w)}}{{c(h)}}$$

KenLM 的 `lmplz` 使用 Modified Kneser–Ney 估计平滑概率；本实验统一使用 `-S 1G` 和 `--discount_fallback`，计数不足以估计折扣时使用后备折扣，具体警告保留在日志中。无剪枝组保留全部观测组合。源码和 Python 查询模块均按最大 10 阶编译。一阶可以由 `lmplz` 估计，但其通用查询类要求至少二阶，因此一阶直接读取导出的 ARPA 概率进行评分。

Stupid Backoff 对已见组合使用条件频率，未见时以固定系数回退：

$$S(w\mid h)=\begin{{cases}}\frac{{c(h,w)}}{{c(h)}},&c(h,w)>0\\\alpha S(w\mid h'),&\text{{otherwise}}\end{{cases}},\quad \alpha=0.4$$

计数程序用整数词 ID 表示组合：Map 阶段对各文本块局部计数，Reduce 阶段对相同键求和，结果保存为排序后的 NumPy 键与计数数组。查询通过二分搜索定位历史及其后续词。这是分布式计数思想的单机实现，没有部署 MapReduce 集群。

环境为 WSL Ubuntu 20.04、{env['cpu']}，WSL 可用内存上限约 {env['memory_bytes']/2**30:.1f} GiB。工程和结果保存在 D 盘，KenLM 输入副本与临时排序文件使用 Linux 临时目录。

## 四、训练时间、规模与过程

KenLM 计时包含 `lmplz` 启动至 ARPA 写出，输入复制不计入。SB 本阶计时包含该阶映射、归并与数组写出，累计时间另含一次公共数据载入。各方法计时顺序执行；实现语言、统计工作量和输出格式不同，耗时不能仅解释为平滑公式的差别。

{main_table}

![训练时间比较](figures/01_training.png)

KenLM 同时完成计数、调整计数、折扣估计、插值与文本模型写出；SB 仅构建回退所需的原始计数，且采用批量数组存储。随阶数增加，KenLM 的完整模型包含更多低阶与高阶条目，ARPA 大小持续增长。SB 的最高阶类型数在五阶为 {stupid[4]['types']:,}，十阶为 {stupid[9]['types']:,}；后者下降是因为有限长度句子中的有效窗口减少，不能将理论组合空间直接等同于实际观测类型数。

训练日志的五个阶段耗时如下，按阶段切换时间估算。

{phase_table}

![训练阶段分解](figures/03_phases.png)

十阶模型的 ARPA 写出阶段约占总时间 **{writer_share:.1f}%**。在当前 WSL 与 D 盘输出条件下，文本模型写出是主要开销之一，说明观察训练过程有助于区分概率计算与文件输出的成本。

SRILM 1.7.3 使用相同训练和留出数据，采用 Kneser–Ney 折扣与插值，并将各阶最低保留计数设为 1。

{sri_table}

两套工具的低阶估计与折扣细节并不完全相同，困惑度和耗时应结合参数配置理解；这里没有将两者当作逐位相同的模型实现。

## 五、测试质量与存储取舍

KenLM 在完整测试集 **{data['splits']['test']['sentences']:,} 句、{data['splits']['test']['prediction_positions_with_eos']:,} 个含句尾预测位置**上评分。困惑度定义为：

$$\operatorname{{PPL}}=\exp\left(-\frac{{1}}{{N}}\sum_{{i=1}}^N\ln P(w_i\mid h_i)\right)$$

![困惑度与阶数](figures/02_perplexity.png)

阶数增加提供更长的局部历史，但高阶稀疏组合仍需依赖低阶分布。五阶至十阶测试 PPL 降低了 {ppm5-ppm10:.2f}，而模型大小增至原来的 {ken[9]['arpa_bytes']/ken[4]['arpa_bytes']:.2f} 倍。根据验证集最低 PPL 选出的阶数为 **{best['order']}**；精度收益还应结合训练与存储成本判断。

固定五阶，比较无剪枝与 `--prune 0 0 1 1 1`，后者去掉三至五阶的孤例组合。

{prune_table}

剪枝后 ARPA 缩小约 **{savings:.1f}%**，相应质量变化由留出 PPL 反映。另将同一个无剪枝五阶 ARPA 构建为 probing 与 trie 二进制，使用 5,000 个相同的预建历史状态进行三轮查询，取每次查询耗时的中位数。

{binary_table}

二进制比较没有量化概率；相同测试 PPL 用于核对存储转换前后的评分。查询时间包含 Python 调用开销，不等同于纯 C++ 查询延迟。

## 六、排序与文本续写

Stupid Backoff 的分数不是规范概率。以三个历史为例，在词表上求和得到：

{norm_table}

因此，仅 KenLM 和 SRILM 计算 PPL。另从测试集随机抽取 150 个正文词位置（不含句尾），候选集固定为训练集最高频的 100 个词加真实目标词，比较相同候选集上的排序。

{rank_table}

上述 Top-1、Top-5 与 MRR 属于受限候选集成绩，不能解释为全词表预测准确率。

续写提示统一为“**在阳光明媚的五月，我们学校胜利召开了……**”，沿用固定词级切分，种子为 42，最多生成 60 个新词，遇句尾符停止。下表按预先设定的参数列出输出节选；完整词序列保存在 `generation.json`。

{generation_table}

二阶续写出现“《中华人民共和国森林法的。”，显示较短历史无法维持提示中的学校主题。五阶贪婪生成转入“第十五次全国代表大会”等语料常见表述，局部搭配较完整，但主题仍发生转移；十阶采样也未保持学校语境。温度 0.5 的五阶输出为“一次大的调整。”，温度 1.2 时则混入武警、医院、市场等不同话题。较高阶数和较低 PPL 因此不能直接等同于长篇语义连贯。

采样时对候选词的对数分数除以温度，再在 top-k 中归一化：

$$q_T(w)=\frac{{\exp(\ell(w)/T)}}{{\sum_{{v\in C_k}}\exp(\ell(v)/T)}}$$

低温度更偏向高分候选，高温度与更大的 k 允许更多低分词进入续写；贪婪生成始终取最高分。SB 的该步骤仅将受限候选集内的分数转为采样权重，没有使其原始全词表分数成为规范概率。输出中局部搭配与长篇主题是否连贯，需要结合具体文本判断，不能只由 PPL 推断。

## 七、代码理解与实验讨论

`prepare_data.py` 负责标记清理、文章去重、分句与词表隔离；`train_kenlm.py` 调用真实估计器并保存阶段日志；`stupid_backoff.py` 实现局部计数、归并、前缀查询和回退；`evaluate.py` 统一评分位置与生成参数。代码中的句首计数核对、n-gram 总计数守恒及存储转换前后 PPL 对照，是检查实现是否符合设计的关键步骤。

对照 KenLM 的 `lm/builder/pipeline.cc`，`Pipeline` 串联计数、`AdjustCounts`、`InitialProbabilities` 与 `InterpolateProbabilities`，对应日志中的调整计数、初始概率和插值阶段。MKN 的低阶分布需要续接计数，不能直接套用普通词频；因此估计过程比原始计数多出调整和插值工作。SB 的 `scores` 则从低阶向高阶逐步乘回退系数，再以已见组合的条件频率覆盖相应候选词，这一循环对应回退公式，也解释了为什么各候选分数相加通常大于 1。

本实验说明，增加 n 能改善局部条件概率，但收益需要与稀疏性和模型成本同时考虑。Stupid Backoff 的简单性体现在统计和回退规则，KenLM 的优势还来自查询数据结构与工程实现。两者的用途和评分含义不同，不能把未归一化分数当作概率，也不能将本次单机速度外推为分布式系统的扩展性能。

参考资料：[KenLM 论文](https://kheafield.com/papers/avenue/kenlm.pdf)、[KenLM 源码](https://github.com/kpu/kenlm)、[SRILM](https://www.sri.com/platform/srilm/)、[Stupid Backoff 原始论文](https://aclanthology.org/D07-1090/)。提供的 [Goodman 2001](https://www.cs.brandeis.edu/~cs136a/CS136a_docs/goodman2001.pdf) 为语言模型与平滑方法综述，Stupid Backoff 则由 Brants 等人在 2007 年提出。
"""
    text = re.sub(r"\$\$\s*([\s\S]*?)\s*\$\$", lambda m: "$$" + re.sub(r"\s+", " ", m.group(1)).strip() + "$$", text).strip() + "\n"
    (OUT / "report.md").write_text(text, encoding="utf-8")
    rendered = rich_text(text)
    (OUT / "piazza_report.html").write_text(rendered, encoding="utf-8")
    # The posting version keeps tables native and leaves upload positions for
    # platforms that strip embedded image data from clipboard content.
    posting = re.sub(r"!\[([^]]+)\]\(([^)]+)\)", lambda m: "【此处插入配图：" + Path(m.group(2)).name + "】", text)
    (OUT / "piazza_text.txt").write_text(posting, encoding="utf-8")
    (ROOT.parent / "作业2_nGram_报告.html").write_text(rendered, encoding="utf-8")
    print(OUT / "report.md")
    print(ROOT.parent / "作业2_nGram_报告.html")


if __name__ == "__main__":
    main()
