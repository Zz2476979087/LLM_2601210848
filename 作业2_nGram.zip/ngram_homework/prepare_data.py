"""Clean the supplied People's Daily archive, split articles, and map rare words.

Only corpus metadata/linguistic tags are removed; body punctuation is retained.
No sentence or article is sampled away from the chosen train/valid/test split.
"""
import argparse
import hashlib
import json
import random
import re
import unicodedata
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parent
ROW = re.compile(r"^(\d{8})-(\d{2})-(\d{3})-(\d{3})\s+(.*)$")
POS = set("a ad ag an b c d dg e f g h i j k l m mq n ng nr nr1 nr2 nrj nrf ns nsf nt nz nx o p q r rg rr rz rzt rzs ry ryt rys s t tg u ud ug uj ul uv uz v vd vg vn w x y z zg ntc ntcf ntcb nts nto nth nhd nhm nis ni nic nit nba nbc nb nf nl nlw nr nrj nrf".split())
END = {"。", "!", "?"}
CLOSE = {"”", "’", "」", "』", ")", "】", "》", '"', "'"}


def write_json(path, data):
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


def decode(raw):
    errors, offset = [], 0
    try:
        return raw.decode("gb18030"), errors
    except UnicodeDecodeError:
        while offset < len(raw):
            try:
                raw[offset:].decode("gb18030")
                break
            except UnicodeDecodeError as error:
                start, end = offset + error.start, offset + error.end
                errors.append({"byte_offset": start, "hex": raw[start:end].hex()})
                offset = end
        return raw.decode("gb18030", errors="replace"), errors


def clean(body, audit, pos_mode=False):
    body, n = re.subn(r"\{[^{}]*\}", "", body)
    audit["pronunciation_tags_removed"] += n
    def entity(match):
        if match.group(2) in POS:
            audit["entity_wrappers_removed"] += 1
            return match.group(1)
        return match.group(0)
    body = re.sub(r"\[([^\[\]]*?)\]([A-Za-z][A-Za-z0-9]*)", entity, body)
    body, n = re.subn(r"</?(?:doc|text|s|p|title|headline)(?:\s[^>]*)?>", " ", body, flags=re.I)
    audit["xml_tags_removed"] += n
    body = unicodedata.normalize("NFKC", body).replace("\ufffd", " ")
    words = []
    for word in body.split():
        if "/" in word:
            stem, suffix = word.rsplit("/", 1)
            measurement = word.lower() in {"t/h", "kcal/h", "km/h", "m/s", "mg/l", "mmol/l"}
            chinese_stem = any("\u4e00" <= c <= "\u9fff" for c in stem)
            if stem and suffix in POS and not measurement and "://" not in word and (pos_mode or chinese_stem):
                audit["pos_suffixes_removed"] += 1
                word = stem
            else:
                audit["slash_tokens_preserved"] += 1
        # Preserve ordinary text; log and strip only non-whitespace controls.
        controls = sum(unicodedata.category(c) == "Cc" for c in word)
        audit["control_characters_removed"] += controls
        word = "".join(c for c in word if unicodedata.category(c) != "Cc")
        if word:
            words.append(word)
    return words


def sentences(paragraphs):
    output = []
    for words in paragraphs:
        current, ended = [], False
        for word in words:
            if ended and word not in CLOSE:
                if any(c.isalnum() for w in current for c in w):
                    output.append(current)
                current, ended = [], False
            current.append(word)
            if word in END:
                ended = True
        if current and any(c.isalnum() for w in current for c in w):
            output.append(current)
    return output


def prepare(root=ROOT):
    target = root / "data/processed"
    target.mkdir(parents=True, exist_ok=True)
    audit = Counter()
    sources, articles = [], {}
    for path in sorted((root / "data/raw").rglob("*.txt")):
        raw = path.read_bytes()
        text, errors = decode(raw)
        source_tokens = text.split()
        tag_candidates = sum("/" in word and word.rsplit("/", 1)[1] in POS for word in source_tokens)
        pos_mode = tag_candidates > 50 and tag_candidates / max(len(source_tokens), 1) > .005
        sources.append({"file": path.name, "sha256": hashlib.sha256(raw).hexdigest(),
                        "bytes": len(raw), "decode_errors": errors, "pos_tagged_mode": pos_mode})
        for line_number, line in enumerate(text.splitlines(), 1):
            audit["raw_lines"] += 1
            if not line.strip():
                continue
            audit["nonempty_records"] += 1
            match = ROW.fullmatch(line.strip())
            if not match:
                raise ValueError("Unexpected input at {}:{}".format(path.name, line_number))
            date, page, number, paragraph_id, body = match.groups()
            words = clean(body, audit, pos_mode)
            article_id = "{}-{}-{}".format(date, page, number)
            article = articles.setdefault(article_id, {"article_id": article_id, "date": date,
                                                       "page": page, "paragraphs": [], "seen": {}})
            previous = article["seen"].setdefault(paragraph_id, [])
            if words in previous:
                audit["identical_record_copies_removed"] += 1
                continue
            if previous:
                audit["reused_record_id_distinct_text_retained"] += 1
            previous.append(words)
            article["paragraphs"].append(words)
    if not sources:
        raise ValueError("Put the extracted corpus .txt files under data/raw/.")
    unique, hashes = [], set()
    for article_id in sorted(articles):
        article = articles[article_id]
        del article["seen"]
        ss = sentences(article["paragraphs"])
        if not ss:
            audit["articles_without_content_removed"] += 1
            continue
        signature = hashlib.sha256("".join(w for p in article["paragraphs"] for w in p).encode()).hexdigest()
        if signature in hashes:
            audit["duplicate_articles_removed"] += 1
            continue
        hashes.add(signature)
        unique.append({"article_id": article_id, "date": article["date"], "page": article["page"],
                       "sha256": signature, "sentences": ss})
    random.Random(42).shuffle(unique)
    train_size = int(len(unique) * .8)
    valid_size = (len(unique) - train_size) // 2
    splits = {"train": unique[:train_size], "valid": unique[train_size:train_size + valid_size],
              "test": unique[train_size + valid_size:]}
    raw_counts = Counter(w for a in splits["train"] for sent in a["sentences"] for w in sent)
    kept = {word for word, count in raw_counts.items() if count >= 2}
    mapped_counts = Counter()
    for word, count in raw_counts.items():
        mapped_counts[word if word in kept else "<UNK>"] += count
    words = ["<s>", "</s>", "<UNK>"] + sorted((w for w in kept if w not in {"<s>", "</s>", "<UNK>"}),
                                                  key=lambda w: (-mapped_counts[w], w))
    word_to_id = {word: i for i, word in enumerate(words)}
    write_json(target / "vocab.json", {"words": words, "counts": dict(mapped_counts), "min_count": 2,
                                       "mapped_unknown": "<UNK>", "kenlm_query_unknown_aliases": ["<UNK>", "<unk>"]})
    statistics = {}
    for name, subset in splits.items():
        stats = {"articles": len(subset), "sentences": 0, "tokens": 0, "mapped_unk_tokens": 0,
                 "months": dict(sorted(Counter(a["date"][:6] for a in subset).items()))}
        with (target / (name + ".txt")).open("w", encoding="utf-8", newline="\n") as text_file, \
             (target / (name + "_ids.jsonl")).open("w", encoding="utf-8", newline="\n") as ids_file:
            for article in subset:
                for sent in article["sentences"]:
                    mapped = [w if w in kept else "<UNK>" for w in sent]
                    text_file.write(" ".join(mapped) + "\n")
                    ids_file.write(json.dumps([word_to_id[w] for w in mapped]) + "\n")
                    stats["sentences"] += 1
                    stats["tokens"] += len(sent)
                    stats["mapped_unk_tokens"] += mapped.count("<UNK>")
        stats["prediction_positions_with_eos"] = stats["tokens"] + stats["sentences"]
        statistics[name] = stats
    split_ids = {name: [a["article_id"] for a in subset] for name, subset in splits.items()}
    write_json(target / "article_split.json", split_ids)
    assert not (set(split_ids["train"]) & set(split_ids["valid"]) or
                set(split_ids["train"]) & set(split_ids["test"]) or
                set(split_ids["valid"]) & set(split_ids["test"]))
    manifest = {"sources": sources, "audit": dict(audit), "raw_articles": len(articles),
                "retained_articles": len(unique), "vocabulary_size_with_specials": len(words),
                "train_raw_types": len(raw_counts), "splits": statistics, "seed": 42,
                "notes": "Punctuation retained; only tags/metadata removed. Whole article isolation. No corpus subsampling."}
    write_json(target / "data_stats.json", manifest)
    print(json.dumps({k: v for k, v in manifest.items() if k != "sources"}, ensure_ascii=False, indent=2))
    return manifest


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, default=ROOT)
    prepare(parser.parse_args().root)
