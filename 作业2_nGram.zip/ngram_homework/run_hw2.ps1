param(
    [string]$CorpusArchive = '',
    [switch]$Setup,
    [switch]$ReportOnly
)
$ErrorActionPreference = 'Stop'
$projectRoot = $PSScriptRoot
$rawDirectory = Join-Path $projectRoot 'data\raw'
New-Item -ItemType Directory -Path $rawDirectory -Force | Out-Null
New-Item -ItemType Directory -Path (Join-Path $projectRoot 'logs') -Force | Out-Null
if ($CorpusArchive) {
    $archivePath = (Resolve-Path -LiteralPath $CorpusArchive).Path
    $members = & tar -tf $archivePath
    if ($LASTEXITCODE -ne 0) { throw 'Cannot inspect corpus archive.' }
    foreach ($member in $members) {
        if ([IO.Path]::IsPathRooted($member) -or (($member -split '[\\/]') -contains '..')) {
            throw 'Archive contains a path outside the project.'
        }
    }
    & tar -xf $archivePath -C $rawDirectory
    if ($LASTEXITCODE -ne 0) { throw 'Corpus extraction failed.' }
}
$linuxLines = & wsl -d Ubuntu -- wslpath -a $projectRoot
if ($LASTEXITCODE -ne 0) { throw 'WSL Ubuntu is required.' }
$linuxRoot = ($linuxLines | Where-Object { $_ -like '/*' } | Select-Object -Last 1).Trim()
if ($Setup) {
    & py -3.12 (Join-Path $projectRoot 'scripts\fetch_sources.py')
    if ($LASTEXITCODE -ne 0) { throw 'Tool source download failed.' }
    & wsl -d Ubuntu -u root -- bash "$linuxRoot/scripts/install_dependencies.sh"
    if ($LASTEXITCODE -ne 0) { throw 'Build dependency installation failed.' }
    & wsl -d Ubuntu -- bash "$linuxRoot/scripts/build_kenlm.sh"
    if ($LASTEXITCODE -ne 0) { throw 'KenLM build failed.' }
    & wsl -d Ubuntu -- bash "$linuxRoot/scripts/build_srilm.sh"
    if ($LASTEXITCODE -ne 0) { throw 'SRILM build failed.' }
}
$linuxPython = "$linuxRoot/.venv-linux/bin/python"
$arguments = @('-d', 'Ubuntu', '--', $linuxPython, '-u', "$linuxRoot/run_pipeline.py")
if ($ReportOnly) { $arguments += '--report-only' }
& wsl @arguments
if ($LASTEXITCODE -ne 0) { throw 'Experiment pipeline failed; inspect logs/.' }
