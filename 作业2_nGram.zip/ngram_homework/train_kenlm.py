"""Train real KenLM lmplz models and preserve timestamped phase logs."""
import argparse
import gc
import hashlib
import json
import platform
import re
import subprocess
import shutil
import time
from pathlib import Path

import psutil

ROOT = Path(__file__).resolve().parent


def train_one(root, order, label=None, prune=None, force=False):
    label = label or "order{}".format(order)
    folder = root / "models/kenlm"
    folder.mkdir(parents=True, exist_ok=True)
    # KenLM mmap/sort buffers are unreliable on WSL's Windows-mounted drvfs.
    # Keep only runtime scratch on Linux; source, logs and results stay on D:.
    scratch = Path("/tmp/ngram_homework_kenlm")
    scratch.mkdir(parents=True, exist_ok=True)
    source_text = root / "data/processed/train.txt"
    cached_text = scratch / "train.txt"
    checksum = hashlib.sha256(source_text.read_bytes()).hexdigest()
    checksum_file = scratch / "train.sha256"
    if not cached_text.exists() or not checksum_file.exists() or checksum_file.read_text() != checksum:
        shutil.copyfile(str(source_text), str(cached_text))
        checksum_file.write_text(checksum)
    result_path = root / "results" / (label + "_training.json")
    arpa = folder / (label + ".arpa")
    if result_path.exists() and arpa.exists() and not force:
        return json.loads(result_path.read_text())
    cmd = [str(root / "build/kenlm/bin/lmplz"), "-o", str(order), "-S", "1G", "-T", str(scratch), "--discount_fallback"]
    if prune:
        cmd += ["--prune"] + list(map(str, prune))
    start = time.perf_counter()
    phases, lines = [], []
    with cached_text.open("rb") as source, arpa.open("wb") as output, \
         (root / "logs" / (label + ".log")).open("w", encoding="utf-8") as log:
        process = subprocess.Popen(cmd, stdin=source, stdout=output, stderr=subprocess.PIPE, text=True, bufsize=1)
        for line in process.stderr:
            elapsed = time.perf_counter() - start
            log.write("[{:.6f}] {}".format(elapsed, line))
            log.flush()
            lines.append(line)
            if re.match(r"=== \d/5", line):
                phases.append({"label": line.strip(), "start_seconds": elapsed})
                print("KENLM n={} {}".format(order, line.strip()), flush=True)
        status = process.wait()
    seconds = time.perf_counter() - start
    if status:
        raise RuntimeError("lmplz exit {}; inspect {} log".format(status, label))
    for index, phase in enumerate(phases):
        end = phases[index + 1]["start_seconds"] if index + 1 < len(phases) else seconds
        phase["seconds"] = max(0, end - phase["start_seconds"])
    ngram_types = {}
    with arpa.open(encoding="utf-8") as file:
        for line in file:
            match = re.match(r"ngram (\d+)=(\d+)", line)
            if match:
                ngram_types[match.group(1)] = int(match.group(2))
            if line.startswith("\\1-grams:"):
                break
    report = {"order": order, "label": label, "seconds": seconds, "arpa_bytes": arpa.stat().st_size,
              "command": cmd, "phases": phases, "ngram_types": ngram_types,
              "fallback_messages": [s.strip() for s in lines if "fallback" in s.lower() or "discount" in s.lower()],
              "prune": prune}
    result_path.write_text(json.dumps(report, indent=2), encoding="utf-8")
    print("KENLM COMPLETE {} {:.2f}s {:.1f}MiB".format(label, seconds, arpa.stat().st_size / 2**20), flush=True)
    return report


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--max-order", type=int, default=10)
    args = parser.parse_args()
    (ROOT / "results").mkdir(exist_ok=True)
    reports = [train_one(ROOT, n) for n in range(1, args.max_order + 1)]
    # A pre-specified storage/quality comparison, not test-driven selection.
    reports.append(train_one(ROOT, 5, "order5_pruned", [0, 0, 1, 1, 1]))
    (ROOT / "results/kenlm_training.json").write_text(json.dumps(reports, indent=2))
    cpu = next(line.split(":", 1)[1].strip() for line in Path("/proc/cpuinfo").read_text().splitlines() if line.startswith("model name"))
    environment = {"platform": platform.platform(), "python": platform.python_version(), "cpu": cpu,
                   "memory_bytes": psutil.virtual_memory().total, "kenlm_max_order": 10,
                   "numpy": __import__("numpy").__version__, "kenlm_commit": json.loads((ROOT / "references/kenlm_source.json").read_text())["commit"]}
    (ROOT / "results/environment.json").write_text(json.dumps(environment, indent=2))


if __name__ == "__main__":
    main()
