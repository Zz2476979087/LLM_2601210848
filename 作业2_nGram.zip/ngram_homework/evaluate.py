"""Full held-out perplexity, matched-candidate ranking and seeded generation."""
import bisect
import gc
import json
import math
import random
import re
import struct
import subprocess
import time
import unicodedata
from collections import OrderedDict
from pathlib import Path

import kenlm
import numpy as np

from stupid_backoff import StupidBackoff

ROOT = Path(__file__).resolve().parent


def read(path):
    return json.loads(path.read_text(encoding="utf-8"))


def save(name, obj):
    (ROOT / "results" / name).write_text(json.dumps(obj, ensure_ascii=False, indent=2), encoding="utf-8")


class KenLM:
    def __init__(self, order, path=None):
        self.order = order
        self.words = read(ROOT / "data/processed/vocab.json")["words"]
        self.path = path or ROOT / "models/kenlm/order{}.arpa".format(order)
        self.cache = OrderedDict()
        if order == 1:
            # lmplz can estimate order 1, but kenlm.Model requires order >= 2.
            # Read the estimated unigram probabilities directly from its ARPA.
            self.unigrams = {}
            in_unigrams = False
            for line in self.path.open(encoding="utf-8"):
                if line.startswith("\\1-grams:"):
                    in_unigrams = True
                elif line.startswith("\\end"):
                    break
                elif in_unigrams and line.strip():
                    values = line.split()
                    self.unigrams[values[1]] = float(values[0])
            self.model = None
        else:
            self.model = kenlm.Model(str(self.path))

    def state(self, history):
        state, other = kenlm.State(), kenlm.State()
        self.model.BeginSentenceWrite(state)
        for word in history:
            if word == "<s>":
                continue
            self.model.BaseScore(state, word, other)
            state, other = other, state
        return state

    def logs(self, history, candidates):
        if self.order == 1:
            return np.array([self.unigrams.get(w, self.unigrams["<unk>"]) for w in candidates]) * math.log(10)
        state = self.state(history)
        other = kenlm.State()
        return np.fromiter((self.model.BaseScore(state, word, other) for word in candidates),
                           dtype=np.float64, count=len(candidates)) * math.log(10)

    def full_logs(self, history):
        key = tuple(history[-(self.order - 1):]) if self.order > 1 else ()
        if key in self.cache:
            return self.cache[key].copy()
        result = self.logs(history, self.words)
        self.cache[key] = result
        if len(self.cache) > 32:
            self.cache.popitem(last=False)
        return result.copy()

    def ppl(self, split):
        start = time.perf_counter()
        likelihood, positions, sentence_count = 0., 0, 0
        for line in (ROOT / "data/processed" / (split + ".txt")).open(encoding="utf-8"):
            line = line.strip()
            words = line.split()
            if self.order == 1:
                likelihood += sum(self.unigrams.get(w, self.unigrams["<unk>"]) for w in words + ["</s>"])
            else:
                likelihood += self.model.score(line, bos=True, eos=True)
            positions += len(words) + 1
            sentence_count += 1
        return {"ppl": 10 ** (-likelihood / positions), "log10_likelihood": likelihood,
                "positions": positions, "sentences": sentence_count,
                "seconds": time.perf_counter() - start}


def sample_positions(split, count=150):
    sentences = [json.loads(line) for line in (ROOT / "data/processed" / (split + "_ids.jsonl")).open()]
    cumulative = np.cumsum([len(s) for s in sentences]).tolist()
    picks = random.Random(42).sample(range(cumulative[-1]), count)
    result = []
    for position in picks:
        sentence_id = bisect.bisect_right(cumulative, position)
        offset = position - (cumulative[sentence_id - 1] if sentence_id else 0)
        sentence = sentences[sentence_id]
        result.append({"sentence_id": sentence_id, "offset": offset,
                       "history_ids": [0] + sentence[:offset], "target_id": sentence[offset]})
    return result


def rank_result(scores, ids, target):
    order = sorted(range(len(ids)), key=lambda i: (-float(scores[i]), ids[i]))
    rank = next(i + 1 for i, index in enumerate(order) if ids[index] == target)
    return [int(rank == 1), int(rank <= 5), 1 / rank]


def ranking(model, stupid, positions, common_ids):
    ken_scores, stupid_scores = [], []
    for position in positions:
        target = position["target_id"]
        candidates = common_ids + ([] if target in common_ids else [target])
        words = [stupid.words[i] for i in candidates]
        history = [stupid.words[i] for i in position["history_ids"]]
        scores = model.logs(history, words)
        ken_scores.append(rank_result(scores, candidates, target))
        values = stupid.scores(position["history_ids"], model.order)
        stupid_scores.append(rank_result(values[candidates], candidates, target))
    return {"KenLM": dict(zip(["top1", "top5", "mrr"], np.mean(ken_scores, axis=0).tolist())),
            "StupidBackoff": dict(zip(["top1", "top5", "mrr"], np.mean(stupid_scores, axis=0).tolist()))}


def generate(model, stupid, order, temperature=.8, top_k=20, greedy=False, alpha=.4, max_tokens=60):
    prompt = "在阳光明媚的五月，我们学校胜利召开了"
    # Fixed word segmentation; only the displayed prompt omits the trailing ellipsis.
    prefix = unicodedata.normalize("NFKC", "在 阳光明媚 的 五月 ， 我们 学校 胜利 召开 了").split()
    history = ["<s>"] + [w if w in stupid.ids else "<UNK>" for w in prefix]
    generator = np.random.default_rng(42)
    generated = []
    start = time.perf_counter()
    eos = False
    for _ in range(max_tokens):
        if model is not None:
            logs = model.full_logs(history)
        else:
            values = stupid.scores(history, order, alpha=alpha)
            logs = np.log(np.maximum(values, np.finfo(float).tiny))
        # Do not generate BOS or unknown placeholders. EOS remains selectable.
        logs[0] = logs[2] = -np.inf
        if greedy:
            word_id = int(np.argmax(logs))
        else:
            indices = np.argpartition(-logs, top_k - 1)[:top_k]
            indices = indices[np.lexsort((indices, -logs[indices]))]
            weights = logs[indices] / temperature
            weights = np.exp(weights - np.max(weights))
            weights /= weights.sum()
            word_id = int(generator.choice(indices, p=weights))
        if word_id == 1:
            eos = True
            break
        word = stupid.words[word_id]
        generated.append(word)
        history.append(word)
    return {"model": "KenLM" if model is not None else "StupidBackoff", "order": order,
            "temperature": temperature, "top_k": top_k, "greedy": greedy, "alpha": alpha,
            "seed": 42, "max_tokens": max_tokens, "stopped_at_eos": eos,
            "new_tokens": len(generated), "prompt": prompt, "prompt_words": prefix,
            "prompt_oov": [w for w in prefix if w not in stupid.ids],
            "continuation_tokens": generated, "continuation": "".join(generated),
            "seconds": time.perf_counter() - start}


def binary_comparison():
    arpa = ROOT / "models/kenlm/order5.arpa"
    builder = ROOT / "build/kenlm/bin/build_binary"
    results, models = [], []
    valid_sentences = [line.split() for line in (ROOT / "data/processed/valid.txt").open(encoding="utf-8")]
    queries = []
    for sentence in valid_sentences:
        for index, word in enumerate(sentence):
            queries.append((sentence[max(0, index - 4):index], word))
            if len(queries) == 5000:
                break
        if len(queries) == 5000:
            break
    for kind in ("probing", "trie"):
        path = ROOT / "models/kenlm" / ("order5." + kind + ".bin")
        begin = time.perf_counter()
        with (ROOT / "logs" / ("build_" + kind + ".log")).open("w") as output:
            subprocess.run([str(builder), "-T", "/tmp/ngram_homework_kenlm/", "-S", "1G", "-w", "after",
                            kind, str(arpa), str(path)], stdout=output, stderr=output, check=True)
        build_seconds = time.perf_counter() - begin
        begin = time.perf_counter()
        model = KenLM(5, path)
        load_seconds = time.perf_counter() - begin
        states = [(model.state(history), word) for history, word in queries]
        output_state = kenlm.State()
        # Warm the interface, then time identical pre-built history-state queries.
        for state, word in states:
            model.model.BaseScore(state, word, output_state)
        repetitions = []
        for _ in range(3):
            begin = time.perf_counter()
            for state, word in states:
                model.model.BaseScore(state, word, output_state)
            repetitions.append(time.perf_counter() - begin)
        quality = model.ppl("test")
        item = {"kind": kind, "bytes": path.stat().st_size, "build_seconds": build_seconds,
                "load_seconds": load_seconds, "queries": len(states), "repetitions": repetitions,
                "median_microseconds_per_query": float(np.median(repetitions)) / len(states) * 1e6,
                "test_ppl": quality["ppl"]}
        results.append(item)
        del model, states
        gc.collect()
    save("binary_comparison.json", results)
    assert abs(results[0]["test_ppl"] - results[1]["test_ppl"]) < .01
    return results


def run():
    stats = read(ROOT / "data/processed/data_stats.json")
    stupid = StupidBackoff(ROOT)
    assert stupid.sentences == stats["splits"]["train"]["sentences"]
    assert stupid.count([0]) == stupid.sentences
    positions = sample_positions("test")
    save("ranking_positions.json", positions)
    common_words = sorted(read(ROOT / "data/processed/vocab.json")["counts"],
                          key=lambda w: (-stupid.base[stupid.ids[w]], stupid.ids[w]))[:100]
    common_ids = [stupid.ids[w] for w in common_words]
    metrics, continuations = [], []
    normalization = []
    for n in range(1, 11):
        print("EVALUATE order={}".format(n), flush=True)
        model = KenLM(n)
        valid, test = model.ppl("valid"), model.ppl("test")
        assert test["positions"] == stats["splits"]["test"]["prediction_positions_with_eos"]
        compare = ranking(model, stupid, positions, common_ids)
        metrics.append({"order": n, "valid": valid, "test": test, "ranking": compare})
        save("evaluation.json", metrics)
        print("PPL n={} valid={:.3f} test={:.3f}".format(n, valid["ppl"], test["ppl"]), flush=True)
        if n in (2, 3, 5, 10):
            continuations.append(generate(model, stupid, n))
        if n == 5:
            for params in [dict(greedy=True), dict(temperature=.5), dict(temperature=1.2), dict(top_k=5), dict(top_k=50)]:
                continuations.append(generate(model, stupid, n, **params))
            for context in (["的"], ["中国", "的"], ["学校", "召开", "了"]):
                log_probs = model.logs(context, stupid.words)
                log_probs[0] = -np.inf
                # KenLM queries treat <UNK> and <unk> as aliases of ID 0.
                # Our vocabulary already contains <UNK>; count it only once.
                mass = float(np.exp(log_probs).sum())
                assert abs(mass - 1.) < 1e-4
                normalization.append({"history": context, "kenlm_probability_sum": mass,
                                      "stupid_score_sum": float(stupid.scores(context, n).sum())})
        save("generation.json", continuations)
        del model
        gc.collect()
    for n in (3, 5, 10):
        continuations.append(generate(None, stupid, n))
    for alpha in (.2, .8):
        continuations.append(generate(None, stupid, 5, alpha=alpha))
    save("generation.json", continuations)
    save("normalization.json", normalization)
    pruned = KenLM(5, ROOT / "models/kenlm/order5_pruned.arpa")
    save("pruning_evaluation.json", {"valid": pruned.ppl("valid"), "test": pruned.ppl("test")})
    del pruned, stupid
    gc.collect()
    binary_comparison()
    print("EVALUATION COMPLETE", flush=True)


if __name__ == "__main__":
    run()
