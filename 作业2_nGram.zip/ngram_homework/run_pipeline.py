"""Execute the full corpus experiment sequentially in the prepared Linux env."""
import argparse
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def run(script):
    print("RUN " + script, flush=True)
    subprocess.run([sys.executable, str(ROOT / script)], cwd=str(ROOT), check=True)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--report-only", action="store_true")
    args = parser.parse_args()
    for name in ("results", "logs"):
        (ROOT / name).mkdir(exist_ok=True)
    if not args.report_only:
        if not (ROOT / "data/processed/data_stats.json").exists():
            run("prepare_data.py")
        run("train_kenlm.py")
        from stupid_backoff import train
        train(ROOT)
        if not (ROOT / "results/srilm_training.json").exists():
            run("train_srilm.py")
        run("evaluate.py")
    run("build_report.py")


if __name__ == "__main__":
    main()
