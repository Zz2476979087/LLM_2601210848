# 人民日报 n-gram 建模、工具比较与续写

## 文件与交付

纯代码包只包含本项目脚本、依赖和说明，不包含语料、训练结果、模型、第三方源代码或报告图片。Piazza 稿件单独交付，使用原生富文本表格，公式保留 `$$...$$`，配图位于对应正文处。

主要脚本：

- `prepare_data.py`：去编号和注音，兼容词性/实体标签，保留标点，按文章去重、分割并建立训练词表。
- `train_kenlm.py`：实际调用 `lmplz`，训练 1—10 阶及五阶剪枝模型，保存阶段日志。
- `stupid_backoff.py`：局部计数、归并、排序数组和 Stupid Backoff 全词表评分。
- `train_srilm.py`：同语料的 SRILM 二、三、五阶折扣插值对照。
- `evaluate.py`：完整留出集 PPL、共同候选集排序、固定种子的全词表 top-k 续写，以及 probing/trie 比较。
- `build_report.py`：读取实测结果，生成原生表格稿件和三张配图。
- `run_pipeline.py`、`run_hw2.ps1`：顺序运行入口。

## 首次运行

需要 Windows、Python 3.12（用于下载）、WSL Ubuntu 20.04 的 Python 3.8。先解压代码包到 D 盘文件夹，在该目录执行：

```powershell
.\run_hw2.ps1 -Setup -CorpusArchive 'D:\人民日报带音语料.rar'
```

将示例中的语料路径换成实际路径。脚本检查压缩包路径后将其解压到 `data/raw/`，下载固定提交版本的 KenLM 和 SRILM 源码并校验 SHA-256，安装编译依赖、构建工具，随后执行完整实验。依赖安装通过 WSL root 运行 apt；编译及实验使用普通 WSL 用户。

SRILM 使用研究社区许可；源文件由用户在运行时从所记录的公开镜像取得，代码包不重新分发 SRILM 源码或二进制。具体许可保留在下载后的工具源码中。

后续运行可复用已存在的语料、工具和模型：

```powershell
.\run_hw2.ps1
.\run_hw2.ps1 -ReportOnly
```

`-ReportOnly` 只读取已完成实验结果生成稿件。若数据或参数改变，请使用新的工程副本，避免误复用旧缓存。

## 数据与评测口径

本次使用前一个作业的 1998 年一至六月带音文件。文章按种子 42 进行约 80%／10%／10% 划分。训练词频为 1 的词和留出集未登录词映射为 `<UNK>`，数值 ID 为 2；句首和句尾 ID 为 0、1。KenLM 查询时 `<UNK>` 与 `<unk>` 是别名，概率求和只计一次。单位 `t/h` 等不会误当词性删除。

所有模型使用全量训练划分，不下采样。KenLM 和 SRILM 的 PPL 包含句尾预测；Stupid Backoff 分数没有归一化，不计算其 PPL。排序使用相同的 150 个测试位置、100 个高频词加真实目标词的受限候选集。续写使用全词表分数再选 top-k，种子固定为 42，最多 60 个新词。

`lmplz` 能估计一阶，但 `kenlm.Model` 要求至少二阶；一阶评测直接读取其 ARPA 概率。二进制比较固定使用五阶无剪枝模型，trie 临时排序放在 Linux `/tmp`，`-w after` 避免 Windows 挂载盘的删除后调整文件大小问题。项目数据和结果仍保存于 D 盘。

## 输出

- `results/piazza_report.html`：用浏览器打开并复制显示的正文，再粘贴到 Piazza 的 Rich text editor。
- `results/report.md`：Markdown 原稿。
- `results/figures/`：三张 PNG 配图；若 Piazza 未保留粘贴的图片，可使用图片按钮上传。
- `results/*.json`、`main_results.csv`：全部实测数值、续写词序列和排名位置。
- `logs/`：每阶估计器、编译及 SRILM 评分日志。

## 阅读代码的重点

1. 为什么按文章隔离再建立词表，如何防止测试词频进入训练统计。
2. `np.unique` 的局部计数与排序归并如何对应 Map/Reduce。
3. 已见组合的条件频率与未见组合乘固定回退系数有何区别。
4. 原始 SB 分数与 top-k 集合内 softmax 采样概率为何不能混用。
5. 最高阶观测类型数下降，为什么不意味着完整高阶模型更小。

## 来源

- KenLM：https://github.com/kpu/kenlm ，提交 `4cb443e60b7bf2c0ddf3c745378f76cb59e254e5`。
- SRILM 公开镜像：https://github.com/BitSpeech/SRILM ，1.7.3，提交 `d571a4424fb0cf08b29fbfccfddd092ea969eae3`。
- KenLM 论文：https://kheafield.com/papers/avenue/kenlm.pdf 。
- Stupid Backoff 原始论文：https://aclanthology.org/D07-1090/ 。
- Goodman 2001 综述：https://www.cs.brandeis.edu/~cs136a/CS136a_docs/goodman2001.pdf 。
