"""Single-machine Map/Reduce-style n-gram counts and exact Stupid Backoff scores.

Each mapper locally sums fixed-width big-endian token-ID keys. The reducer sorts
and sums equal keys. Sorted NumPy files support binary-search prefix queries.
Scores are NOT globally normalized probabilities and must not be used for PPL.
"""
import gc
import json
import struct
import time
from pathlib import Path

import numpy as np


def train(root, max_order=10, chunk_sentences=4096, force=False):
    root = Path(root)
    destination = root / "models/stupid"
    destination.mkdir(parents=True, exist_ok=True)
    started = time.perf_counter()
    sequences = []
    with (root / "data/processed/train_ids.jsonl").open() as file:
        for line in file:
            sequences.append(np.array([0] + json.loads(line) + [1], dtype=">u4"))
    load_seconds = time.perf_counter() - started
    reports = []
    cumulative = load_seconds
    for n in range(1, max_order + 1):
        metadata = destination / ("order{}.json".format(n))
        if metadata.exists() and not force:
            item = json.loads(metadata.read_text())
            reports.append(item)
            cumulative = item["cumulative_seconds"]
            continue
        begin = time.perf_counter()
        mapped_keys, mapped_counts = [], []
        windows_count = 0
        for start in range(0, len(sequences), chunk_sentences):
            blocks = []
            for seq in sequences[start:start + chunk_sentences]:
                if len(seq) >= n:
                    window = np.lib.stride_tricks.sliding_window_view(seq, n).copy()
                    blocks.append(window.view("S{}".format(4 * n)).reshape(-1))
            if not blocks:
                continue
            keys = np.concatenate(blocks)
            windows_count += len(keys)
            keys, counts = np.unique(keys, return_counts=True)
            mapped_keys.append(keys)
            mapped_counts.append(counts.astype(np.uint32))
        mapper_seconds = time.perf_counter() - begin
        keys = np.concatenate(mapped_keys)
        counts = np.concatenate(mapped_counts)
        del mapped_keys, mapped_counts, blocks
        order = np.argsort(keys)
        keys, counts = keys[order], counts[order]
        del order
        boundaries = np.r_[0, np.flatnonzero(keys[1:] != keys[:-1]) + 1]
        counts = np.add.reduceat(counts.astype(np.uint64), boundaries)
        assert int(counts.sum()) == windows_count
        assert int(counts.max()) < 2**32
        keys = keys[boundaries]
        np.save(str(destination / ("keys{}.npy".format(n))), keys)
        np.save(str(destination / ("counts{}.npy".format(n))), counts.astype(np.uint32))
        seconds = time.perf_counter() - begin
        cumulative += seconds
        item = {"order": n, "seconds": seconds, "mapper_seconds": mapper_seconds,
                "reduce_and_write_seconds": seconds - mapper_seconds,
                "cumulative_seconds": cumulative, "initial_load_seconds": load_seconds,
                "types": len(keys), "events": windows_count,
                "file_bytes": sum((destination / ("{}{}.npy".format(prefix, n))).stat().st_size
                                  for prefix in ("keys", "counts"))}
        metadata.write_text(json.dumps(item, indent=2), encoding="utf-8")
        reports.append(item)
        print("STUPID n={} types={} seconds={:.2f}".format(n, len(keys), seconds), flush=True)
        del keys, counts, boundaries
        gc.collect()
    (root / "results/stupid_training.json").write_text(json.dumps(reports, indent=2))
    return reports


class StupidBackoff:
    def __init__(self, root, max_order=10, alpha=.4):
        root = Path(root)
        vocab = json.loads((root / "data/processed/vocab.json").read_text(encoding="utf-8"))
        self.words = vocab["words"]
        self.ids = {word: i for i, word in enumerate(self.words)}
        self.alpha = alpha
        self.keys, self.counts = {}, {}
        for n in range(1, max_order + 1):
            self.keys[n] = np.load(str(root / "models/stupid/keys{}.npy".format(n)))
            self.counts[n] = np.load(str(root / "models/stupid/counts{}.npy".format(n)))
        self.max_order = max_order
        self.base = np.zeros(len(self.words), dtype=np.float64)
        word_ids = self.keys[1].view(">u4").reshape(-1)
        self.base[word_ids] = self.counts[1]
        self.sentences = int(self.base[0])
        self.base[0] = 0
        self.base /= self.base.sum()

    def count(self, ids):
        n = len(ids)
        key = struct.pack(">{}I".format(n), *ids)
        keys = self.keys[n]
        index = int(np.searchsorted(keys, np.array(key, dtype=keys.dtype)))
        if index < len(keys) and bytes(keys[index]).ljust(4 * n, b"\0") == key:
            return int(self.counts[n][index])
        return 0

    def followers(self, history):
        n = len(history) + 1
        prefix = struct.pack(">{}I".format(n - 1), *history)
        low = prefix + b"\0\0\0\0"
        high_prefix = (int.from_bytes(prefix, "big") + 1).to_bytes(len(prefix), "big")
        high = high_prefix + b"\0\0\0\0"
        keys = self.keys[n]
        first = int(np.searchsorted(keys, np.array(low, dtype=keys.dtype)))
        last = int(np.searchsorted(keys, np.array(high, dtype=keys.dtype)))
        ids = keys[first:last].view(">u4").reshape(-1, n)[:, -1]
        return ids, self.counts[n][first:last]

    def scores(self, history, order, alpha=None):
        """Score the complete vocabulary, without top-candidate approximations."""
        alpha = self.alpha if alpha is None else alpha
        history = [self.ids.get(w, 2) if isinstance(w, str) else int(w) for w in history]
        values = self.base.copy()
        for length in range(1, min(order - 1, len(history)) + 1):
            context = history[-length:]
            denominator = self.count(context)
            values *= alpha
            if denominator:
                ids, counts = self.followers(context)
                values[ids] = counts / denominator
        values[0] = 0
        return values
