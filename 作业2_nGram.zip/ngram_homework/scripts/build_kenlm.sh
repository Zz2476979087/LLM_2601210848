#!/usr/bin/env bash
set -euo pipefail
project_dir="$(cd "$(dirname "$0")/.." && pwd)"
source_dir="$(find "$project_dir/vendor" -mindepth 1 -maxdepth 1 -type d -name 'kenlm-*' | head -n 1)"
python3 -m venv --copies "$project_dir/.venv-linux"
"$project_dir/.venv-linux/bin/python" -m pip install --upgrade pip==25.0.1 setuptools==75.3.2 wheel
"$project_dir/.venv-linux/bin/python" -m pip install -r "$project_dir/requirements-linux.txt"
cmake -S "$source_dir" -B "$project_dir/build/kenlm" -DKENLM_MAX_ORDER=10 -DCMAKE_BUILD_TYPE=Release -DENABLE_INTERPOLATE=OFF
cmake --build "$project_dir/build/kenlm" --target lmplz build_binary query -j 8
MAX_ORDER=10 "$project_dir/.venv-linux/bin/python" -m pip install --no-build-isolation "$source_dir"
