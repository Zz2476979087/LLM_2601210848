#!/usr/bin/env bash
set -euo pipefail
project_dir="$(cd "$(dirname "$0")/.." && pwd)"
source_dir="$(find "$project_dir/vendor" -mindepth 1 -maxdepth 1 -type d -name 'SRILM-*' | head -n 1)"
make -C "$source_dir" SRILM="$source_dir" MACHINE_TYPE=i686-m64 NO_TCL=1 NO_ICONV=1 -j 8 World
