"""Download pinned upstream tool sources; do not include them in the code ZIP."""
import hashlib
import io
import json
import os
from pathlib import Path
from urllib.request import Request, urlopen
import zipfile

ROOT = Path(__file__).resolve().parents[1]
SOURCES = [
    ("kenlm", "kpu/kenlm", "4cb443e60b7bf2c0ddf3c745378f76cb59e254e5", "eea5d0f70513ad6664fb7861bd55af888cbc967eef289a0429f52396f1808a59"),
    ("srilm", "BitSpeech/SRILM", "d571a4424fb0cf08b29fbfccfddd092ea969eae3", "d68cda5d8abeeaf05fe450367b3563c492c1a0bdcf4357fb7782eb3b89c50e60"),
]


def main():
    (ROOT / "vendor").mkdir(exist_ok=True)
    (ROOT / "references").mkdir(exist_ok=True)
    for name, repository, commit, checksum in SOURCES:
        archive_root = repository.split("/")[-1] + "-" + commit
        directory = ROOT / "vendor" / archive_root
        url = "https://codeload.github.com/{}/zip/{}".format(repository, commit)
        if not directory.exists():
            with urlopen(Request(url, headers={"User-Agent": "ngram-course-experiment"}), timeout=120) as response:
                content = response.read()
            if hashlib.sha256(content).hexdigest() != checksum:
                raise ValueError("Source archive checksum mismatch for " + name)
            with zipfile.ZipFile(io.BytesIO(content)) as archive:
                for item in archive.infolist():
                    member = Path(item.filename)
                    if member.is_absolute() or ".." in member.parts:
                        raise ValueError("Unsafe source archive member")
                archive.extractall(ROOT / "vendor")
                if os.name != "nt":
                    for item in archive.infolist():
                        permission = (item.external_attr >> 16) & 0o777
                        if permission:
                            (ROOT / "vendor" / item.filename).chmod(permission)
        metadata = {"commit": commit, "source_url": url, "archive_sha256": checksum,
                    "source_directory": str(directory), "repository": repository}
        (ROOT / "references" / (name + "_source.json")).write_text(json.dumps(metadata, indent=2))
        print(name, commit)


if __name__ == "__main__":
    main()
